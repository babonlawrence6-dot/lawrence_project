-- ============================================================
-- Seven Evelyn POS - V4 migration for an EXISTING V3 database
-- Run this after importing the V3 database. Back up the database first.
-- The migration below uses IF NOT EXISTS so it can be safely re-run.
-- ============================================================
USE pos_db;

CREATE TABLE IF NOT EXISTS locations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS location_stock (
    id INT AUTO_INCREMENT PRIMARY KEY,
    location_id INT NOT NULL,
    product_id INT NOT NULL,
    stock INT NOT NULL DEFAULT 0,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_location_product (location_id, product_id),
    FOREIGN KEY (location_id) REFERENCES locations(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS stock_movements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    movement_type VARCHAR(30) NOT NULL,
    quantity_change INT NOT NULL,
    reference_no VARCHAR(80) DEFAULT NULL,
    user_id INT DEFAULT NULL,
    location VARCHAR(100) DEFAULT 'Main Store',
    notes VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_stock_movement_product (product_id),
    INDEX idx_stock_movement_created (created_at),
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

INSERT IGNORE INTO locations (name, active) VALUES
('Main Store', 1),('Warehouse', 1),('Branch 1', 1),('Branch 2', 1);

INSERT INTO location_stock (location_id, product_id, stock)
SELECT l.id, p.id, p.stock
FROM locations l CROSS JOIN products p
WHERE l.name='Main Store'
ON DUPLICATE KEY UPDATE stock=location_stock.stock;

ALTER TABLE transaction_items ADD COLUMN IF NOT EXISTS cost_price DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER unit_price;
UPDATE transaction_items ti JOIN products p ON p.id=ti.product_id SET ti.cost_price=p.cost_price WHERE ti.cost_price=0.00;
