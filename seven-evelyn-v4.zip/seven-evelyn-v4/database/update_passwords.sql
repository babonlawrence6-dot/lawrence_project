-- Run these in phpMyAdmin or MySQL console to update existing users' passwords
UPDATE users SET password = '$2y$10$DtkXajY.IiXVmBbinibhtOAQnofhV840ws2/l1XQGK2.wgB/8WL0K' WHERE username = 'admin';
UPDATE users SET password = '$2y$10$tAcC3tsX4l73tmSnsndJhuNzWI5U/QZlnx3T.XvxA7VJlwhYaDzl6' WHERE username = 'cashier1';
