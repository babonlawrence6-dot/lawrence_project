-- ============================================================
-- POS System Database
-- Import this file into phpMyAdmin in XAMPP
-- ============================================================

CREATE DATABASE IF NOT EXISTS pos_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE pos_db;

-- ============================================================
-- USERS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    role ENUM('admin', 'cashier', 'manager', 'inventory', 'warehouse', 'accountant', 'owner') NOT NULL DEFAULT 'cashier',
    status ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================
-- CATEGORIES TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================
-- PRODUCTS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    barcode VARCHAR(50) UNIQUE,
    name VARCHAR(200) NOT NULL,
    category_id INT,
    price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    cost_price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    stock INT NOT NULL DEFAULT 0,
    low_stock_threshold INT NOT NULL DEFAULT 10,
    image VARCHAR(255) DEFAULT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ============================================================
-- TRANSACTIONS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    transaction_no VARCHAR(50) NOT NULL UNIQUE,
    user_id INT NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    discount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    grand_total DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    payment_method ENUM('cash', 'card', 'ewallet') NOT NULL DEFAULT 'cash',
    amount_paid DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    change_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    status ENUM('completed', 'cancelled') NOT NULL DEFAULT 'completed',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB;

-- ============================================================
-- TRANSACTION ITEMS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS transaction_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    transaction_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    unit_price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    cost_price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    subtotal DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    FOREIGN KEY (transaction_id) REFERENCES transactions(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id)
) ENGINE=InnoDB;

-- ============================================================
-- SEED DATA - Default Admin and Cashier Accounts
-- ============================================================
-- Passwords: admin123 and cashier123 (bcrypt hashed)
INSERT IGNORE INTO users (username, password, full_name, role, status) VALUES
('admin', '$2y$10$DtkXajY.IiXVmBbinibhtOAQnofhV840ws2/l1XQGK2.wgB/8WL0K', 'System Administrator', 'admin', 'active'),
('cashier1', '$2y$10$tAcC3tsX4l73tmSnsndJhuNzWI5U/QZlnx3T.XvxA7VJlwhYaDzl6', 'Cashier One', 'cashier', 'active');

-- ============================================================
-- SEED DATA - Sample Categories
-- ============================================================
INSERT INTO categories (name, description) VALUES
('Beverages', 'Drinks and beverages'),
('Snacks', 'Snack items'),
('Dairy', 'Dairy products'),
('Bakery', 'Bakery items'),
('Frozen', 'Frozen food items'),
('Household', 'Household essentials');

-- ============================================================
-- SEED DATA - Sample Products
-- ============================================================
INSERT INTO products (barcode, name, category_id, price, cost_price, stock, low_stock_threshold) VALUES
('4800001001', 'Coca-Cola 330ml', 1, 1.50, 0.80, 100, 20),
('4800001002', 'Pepsi 330ml', 1, 1.50, 0.80, 80, 20),
('4800001003', 'Orange Juice 1L', 1, 3.50, 1.80, 40, 10),
('4800002001', 'Potato Chips', 2, 2.00, 0.90, 60, 15),
('4800002002', 'Chocolate Bar', 2, 1.80, 0.70, 120, 20),
('4800003001', 'Fresh Milk 1L', 3, 2.50, 1.50, 50, 15),
('4800003002', 'Cheddar Cheese 250g', 3, 4.50, 2.50, 30, 10),
('4800004001', 'White Bread', 4, 2.20, 1.00, 25, 10),
('4800004002', 'Croissant', 4, 1.50, 0.60, 35, 10),
('4800005001', 'Frozen Pizza', 5, 5.50, 3.00, 20, 5),
('4800006001', 'Dish Soap 500ml', 6, 3.00, 1.50, 45, 10),
('4800006002', 'Laundry Detergent 1kg', 6, 6.50, 3.50, 30, 8);


-- ============================================================
-- WAREHOUSE TABLES
-- ============================================================
CREATE TABLE IF NOT EXISTS deliveries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    reference_no VARCHAR(50) NOT NULL UNIQUE,
    supplier_name VARCHAR(100),
    received_by INT NOT NULL,
    total_items INT DEFAULT 0,
    status ENUM('pending', 'received', 'cancelled') DEFAULT 'pending',
    received_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (received_by) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS delivery_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    delivery_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    cost_price DECIMAL(10,2),
    FOREIGN KEY (delivery_id) REFERENCES deliveries(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS stock_transfers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    transfer_no VARCHAR(50) NOT NULL UNIQUE,
    from_location VARCHAR(100) NOT NULL,
    to_location VARCHAR(100) NOT NULL,
    processed_by INT NOT NULL,
    status ENUM('pending', 'completed', 'cancelled') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (processed_by) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS stock_transfer_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    transfer_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    FOREIGN KEY (transfer_id) REFERENCES stock_transfers(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id)
) ENGINE=InnoDB;

-- ============================================================
-- V4 INVENTORY LOCATIONS / AUDIT TRAIL
-- ============================================================
CREATE TABLE IF NOT EXISTS locations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS location_stock (
    id INT AUTO_INCREMENT PRIMARY KEY,
    location_id INT NOT NULL,
    product_id INT NOT NULL,
    stock INT NOT NULL DEFAULT 0,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_location_product (location_id, product_id),
    FOREIGN KEY (location_id) REFERENCES locations(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS stock_movements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    movement_type VARCHAR(30) NOT NULL,
    quantity_change INT NOT NULL,
    reference_no VARCHAR(80) DEFAULT NULL,
    user_id INT DEFAULT NULL,
    location VARCHAR(100) DEFAULT 'Main Store',
    notes VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_stock_movement_product (product_id),
    INDEX idx_stock_movement_created (created_at),
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS locations_seed_marker (id TINYINT PRIMARY KEY) ENGINE=InnoDB;
INSERT IGNORE INTO locations_seed_marker (id) VALUES (1);
INSERT IGNORE INTO locations (name, active) VALUES
('Main Store', 1),
('Warehouse', 1),
('Branch 1', 1),
('Branch 2', 1);

-- Preserve existing product stock as Main Store stock on first initialization.
INSERT INTO location_stock (location_id, product_id, stock)
SELECT l.id, p.id, p.stock
FROM locations l CROSS JOIN products p
WHERE l.name='Main Store'
ON DUPLICATE KEY UPDATE stock=location_stock.stock;

-- Transaction items keep the cost at the time of sale so historical profit stays accurate.
