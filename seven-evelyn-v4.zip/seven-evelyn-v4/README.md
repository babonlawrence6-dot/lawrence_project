# Seven Evelyn POS System – V4

A role-based PHP/MySQL Point-of-Sale system with product management, inventory, checkout, reports, warehouse deliveries, stock transfers, user management, and inventory audit history.

## V4 fixes and completed features

- Secure server-side checkout pricing and stock validation
- Prevents negative stock during sales and transfers
- Validates cash payment and non-cash payment totals
- Active/inactive user enforcement at login and on protected requests
- Session ID regeneration after successful login
- POST + CSRF protection for destructive product/category/user actions
- Prevents deletion of products with sales history
- User accounts with transaction/history are deactivated instead of deleted
- Prevents deactivation of the last active administrator
- Completed warehouse stock transfer workflow
- Location stock support: Main Store, Warehouse, Branch 1, Branch 2
- Supplier delivery receiving updates Main Store stock
- Stock movement audit history for sales, deliveries, restocks, adjustments, and transfers
- Historical cost price snapshot for future transaction items
- Sample products use local product photos in Sales / Checkout and Product Management; uploaded images override the defaults.
- Laundry Detergent 1kg uses a real washing-powder photo from Wikimedia Commons, released into the public domain.
- Best-selling reports ignore cancelled transactions
- Profit report uses transaction grand totals and saved transaction-item cost
- PHP syntax and JavaScript syntax checked

## Installation – New Database

1. Create/import the database using `database/pos_db.sql`.
2. Configure `includes/config.php` for your MySQL credentials.
3. Open `index.php` in XAMPP/your PHP server.

## Updating an Existing V3 Database

1. Back up your existing `pos_db` database first.
2. Run `database/update_v4.sql` once.
3. Keep the existing data.
4. Replace the old application files with this V4 version.

The migration initializes the Main Store location from the existing `products.stock` values. Existing historical transaction costs are backfilled from the product's current cost price because the old V3 database did not store a cost snapshot; future sales store the cost at the time of sale.

## Default Accounts

- Admin: `admin` / `admin123`
- Cashier: `cashier1` / `cashier123`
- Additional role accounts may be created from User Management.

Change default passwords before real deployment.


## V4.1 hardening included in this package

- Server-side role authorization now runs before checkout, warehouse, and report requests are processed.
- Checkout uses Post/Redirect/Get after a successful sale, preventing duplicate transactions caused by browser refresh.
- Product stock edits are recorded in the stock-movement audit trail.
- Base `pos_db.sql` now creates `transaction_items.cost_price` directly, avoiding an unnecessary ALTER during a fresh installation.
- PHP and JavaScript syntax were re-checked after the changes.

### Testing note
The package has been statically validated, but a live end-to-end test still requires XAMPP/Apache + MySQL/MariaDB. After importing the database, test login, each role, product CRUD, stock adjustment, checkout, delivery, transfer, and reports.
