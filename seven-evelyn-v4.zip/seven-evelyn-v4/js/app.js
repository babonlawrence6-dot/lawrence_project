/* ============================================================
   POS System - Application JavaScript
   ============================================================ */

document.addEventListener('DOMContentLoaded', function() {
    // Mobile menu toggle
    const menuToggle = document.getElementById('menuToggle');
    const sidebar = document.getElementById('sidebar');

    if (menuToggle && sidebar) {
        menuToggle.addEventListener('click', function() {
            sidebar.classList.toggle('open');
        });

        // Close sidebar when clicking outside on mobile
        document.addEventListener('click', function(e) {
            if (window.innerWidth <= 768 && 
                !sidebar.contains(e.target) && 
                !menuToggle.contains(e.target)) {
                sidebar.classList.remove('open');
            }
        });
    }

    // Auto-dismiss alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert-dismissible');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            alert.style.opacity = '0';
            alert.style.transform = 'translateY(-10px)';
            alert.style.transition = 'all 0.3s ease';
            setTimeout(function() {
                alert.remove();
            }, 300);
        }, 5000);
    });

    // Close modals on outside click
    document.querySelectorAll('.modal').forEach(function(modal) {
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                modal.classList.remove('active');
            }
        });
    });

    // Close modals with Escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            document.querySelectorAll('.modal.active').forEach(function(modal) {
                modal.classList.remove('active');
            });
        }
    });

    // Confirm delete actions
    document.querySelectorAll('a[href*="delete"]').forEach(function(link) {
        link.addEventListener('click', function(e) {
            if (!confirm('Are you sure you want to delete this item?')) {
                e.preventDefault();
            }
        });
    });

    // Number input validation
    document.querySelectorAll('input[type="number"]').forEach(function(input) {
        input.addEventListener('keydown', function(e) {
            // Prevent negative values
            if (e.key === '-' && this.getAttribute('min') === '0') {
                e.preventDefault();
            }
        });
    });

    // Table row hover effect
    document.querySelectorAll('.table tbody tr').forEach(function(row) {
        row.addEventListener('mouseenter', function() {
            this.style.backgroundColor = '#f8f9fa';
        });
        row.addEventListener('mouseleave', function() {
            this.style.backgroundColor = '';
        });
    });

    // Replace every native <select> dropdown with the custom cs-* widget
    enhanceSelects();

    // Flash message on page load (if URL has params)
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.has('msg')) {
        const msg = document.createElement('div');
        msg.className = 'alert alert-success alert-dismissible';
        msg.innerHTML = '<i class="fas fa-check-circle"></i> ' + 
            decodeURIComponent(urlParams.get('msg')) + 
            '<button class="close-btn" onclick="this.parentElement.remove()">&times;</button>';
        const content = document.querySelector('.content-wrapper');
        if (content) {
            content.insertBefore(msg, content.firstChild);
        }
    }
});

// ============================================================
// Custom Select Dropdown
// ============================================================
// Progressively enhances every <select> on the page into a fully
// styleable custom dropdown (native <select> popups can't be themed
// consistently across browsers/OSes). The original <select> is kept
// in the DOM but visually hidden, so:
//   - form submission still sends the same name/value pairs
//   - existing inline onchange="" handlers still fire
//   - existing document.getElementById(...) lookups still work
function enhanceSelects() {
    document.querySelectorAll('select').forEach(function (select) {
        if (select.multiple || select.dataset.csEnhanced) return;
        select.dataset.csEnhanced = 'true';

        const wrapper = document.createElement('div');
        wrapper.className = 'cs-wrapper';

        const trigger = document.createElement('button');
        trigger.type = 'button';
        trigger.className = 'cs-trigger';
        trigger.setAttribute('aria-haspopup', 'listbox');
        trigger.setAttribute('aria-expanded', 'false');

        const labelSpan = document.createElement('span');
        labelSpan.className = 'cs-trigger-label';
        trigger.appendChild(labelSpan);

        const caret = document.createElement('i');
        caret.className = 'fas fa-chevron-down cs-caret';
        trigger.appendChild(caret);

        const list = document.createElement('ul');
        list.className = 'cs-options';
        list.setAttribute('role', 'listbox');

        function optionEls() {
            return Array.from(list.querySelectorAll('.cs-option'));
        }

        function sync() {
            const opt = select.options[select.selectedIndex];
            labelSpan.textContent = opt ? opt.textContent.trim() : '';
            labelSpan.classList.toggle('cs-placeholder', !!opt && opt.value === '');
            optionEls().forEach(function (li) {
                const isSelected = li.dataset.value === select.value;
                li.classList.toggle('selected', isSelected);
                const check = li.querySelector('.fa-check');
                if (isSelected && !check) {
                    li.insertAdjacentHTML('beforeend', '<i class="fas fa-check"></i>');
                } else if (!isSelected && check) {
                    check.remove();
                }
            });
            wrapper.classList.remove('cs-invalid');
        }

        function buildOptions() {
            list.innerHTML = '';
            Array.from(select.options).forEach(function (opt) {
                const li = document.createElement('li');
                li.className = 'cs-option' + (opt.disabled ? ' disabled' : '');
                li.setAttribute('role', 'option');
                li.dataset.value = opt.value;
                li.innerHTML = '<span>' + opt.textContent.trim() + '</span>';
                if (!opt.disabled) {
                    li.addEventListener('click', function () {
                        select.value = opt.value;
                        select.dispatchEvent(new Event('change', { bubbles: true }));
                        sync();
                        close();
                        trigger.focus();
                    });
                }
                list.appendChild(li);
            });
            sync();
        }

        function open() {
            document.querySelectorAll('.cs-wrapper.open').forEach(function (w) {
                if (w !== wrapper) w.classList.remove('open');
            });
            wrapper.classList.add('open');
            trigger.setAttribute('aria-expanded', 'true');
            optionEls().forEach(function (li) { li.classList.remove('focused'); });
            const active = list.querySelector('.cs-option.selected') || list.querySelector('.cs-option:not(.disabled)');
            if (active) {
                active.classList.add('focused');
                active.scrollIntoView({ block: 'nearest' });
            }
        }

        function close() {
            wrapper.classList.remove('open');
            trigger.setAttribute('aria-expanded', 'false');
        }

        function moveFocus(step) {
            const opts = optionEls().filter(function (li) { return !li.classList.contains('disabled'); });
            if (!opts.length) return;
            let idx = opts.findIndex(function (li) { return li.classList.contains('focused'); });
            idx = idx === -1 ? 0 : Math.min(opts.length - 1, Math.max(0, idx + step));
            opts.forEach(function (li) { li.classList.remove('focused'); });
            opts[idx].classList.add('focused');
            opts[idx].scrollIntoView({ block: 'nearest' });
        }

        trigger.addEventListener('click', function () {
            wrapper.classList.contains('open') ? close() : open();
        });

        trigger.addEventListener('keydown', function (e) {
            if (['ArrowDown', 'ArrowUp', 'Enter', ' ', 'Escape'].indexOf(e.key) === -1) return;
            e.preventDefault();
            if (e.key === 'Escape') { close(); return; }
            if (!wrapper.classList.contains('open')) {
                if (e.key === 'ArrowDown' || e.key === 'ArrowUp') open();
                else if (e.key === 'Enter' || e.key === ' ') open();
                return;
            }
            if (e.key === 'ArrowDown') moveFocus(1);
            else if (e.key === 'ArrowUp') moveFocus(-1);
            else {
                const focused = list.querySelector('.cs-option.focused');
                if (focused) focused.click();
                else close();
            }
        });

        // Keep the widget in sync if the select's value is ever changed
        // by other code (e.g. resetting a form).
        select.addEventListener('change', sync);

        // Preserve label[for="..."] accessibility by pointing it at the
        // new visible trigger instead of the now-hidden native select.
        if (select.id) {
            const boundLabel = document.querySelector('label[for="' + select.id + '"]');
            if (boundLabel) {
                trigger.id = select.id + '-cs-trigger';
                boundLabel.setAttribute('for', trigger.id);
            }
        }

        if (select.disabled) {
            trigger.disabled = true;
            wrapper.classList.add('cs-disabled');
        }

        buildOptions();

        select.classList.add('cs-native-hidden');
        select.insertAdjacentElement('afterend', wrapper);
        wrapper.appendChild(trigger);
        wrapper.appendChild(list);
    });

    document.addEventListener('click', function (e) {
        document.querySelectorAll('.cs-wrapper.open').forEach(function (w) {
            if (!w.contains(e.target)) w.classList.remove('open');
        });
    }, { capture: true });

    // A hidden <select> is barred from native HTML5 "required" validation,
    // so enforce it ourselves on submit and flag the visible trigger.
    document.querySelectorAll('form').forEach(function (form) {
        if (form.dataset.csValidationBound) return;
        form.dataset.csValidationBound = 'true';
        form.addEventListener('submit', function (e) {
            let firstInvalid = null;
            form.querySelectorAll('select.cs-native-hidden[required]').forEach(function (select) {
                const wrapper = select.nextElementSibling;
                if (!wrapper || !wrapper.classList.contains('cs-wrapper')) return;
                if (!select.value) {
                    wrapper.classList.add('cs-invalid');
                    if (!firstInvalid) firstInvalid = wrapper;
                } else {
                    wrapper.classList.remove('cs-invalid');
                }
            });
            if (firstInvalid) {
                e.preventDefault();
                firstInvalid.scrollIntoView({ block: 'center' });
                firstInvalid.querySelector('.cs-trigger').focus();
            }
        });
    });
}

// Utility: Format currency
function formatCurrency(amount) {
    return '₱' + parseFloat(amount).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

// Utility: Get current date/time
function getCurrentDateTime() {
    const now = new Date();
    return now.toLocaleString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });
}
