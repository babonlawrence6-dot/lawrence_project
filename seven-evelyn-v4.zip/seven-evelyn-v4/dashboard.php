<?php
$pageTitle = 'Dashboard';
require_once 'includes/header.php';

// Fetch dashboard statistics
$stats = [];

// Total products
$stmt = $pdo->query("SELECT COUNT(*) as total FROM products");
$stats['total_products'] = $stmt->fetch()['total'];

// Total revenue today
$stmt = $pdo->query("SELECT COALESCE(SUM(grand_total), 0) as total FROM transactions WHERE DATE(created_at) = CURDATE() AND status = 'completed'");
$stats['today_sales'] = $stmt->fetch()['total'];

// Total transactions today
$stmt = $pdo->query("SELECT COUNT(*) as total FROM transactions WHERE DATE(created_at) = CURDATE() AND status = 'completed'");
$stats['today_transactions'] = $stmt->fetch()['total'];

// Low stock items
$stmt = $pdo->query("SELECT COUNT(*) as total FROM products WHERE stock <= low_stock_threshold");
$stats['low_stock'] = $stmt->fetch()['total'];

// Recent transactions
$stmt = $pdo->query("SELECT t.*, u.full_name FROM transactions t LEFT JOIN users u ON t.user_id = u.id ORDER BY t.created_at DESC LIMIT 5");
$recent_transactions = $stmt->fetchAll();

// Low stock products
$stmt = $pdo->query("SELECT p.*, c.name as category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id WHERE p.stock <= p.low_stock_threshold ORDER BY p.stock ASC LIMIT 5");
$low_stock_products = $stmt->fetchAll();
?>

<div class="dashboard-grid">
    <!-- Stats Cards -->
    <div class="stat-card">
        <div class="stat-icon bg-blue">
            <i class="fas fa-box"></i>
        </div>
        <div class="stat-info">
            <h3><?php echo number_format($stats['total_products']); ?></h3>
            <p>Total Products</p>
        </div>
    </div>

    <?php if (in_array($current_role, ['admin', 'owner', 'accountant', 'manager', 'cashier'])): ?>
    <div class="stat-card">
        <div class="stat-icon bg-green">
            <i class="fas fa-money-bill-wave"></i>
        </div>
        <div class="stat-info">
            <h3>₱<?php echo number_format($stats['today_sales'], 2); ?></h3>
            <p>Today's Sales</p>
        </div>
    </div>
    <?php endif; ?>

    <?php if (in_array($current_role, ['admin', 'owner', 'accountant', 'manager', 'cashier'])): ?>
    <div class="stat-card">
        <div class="stat-icon bg-purple">
            <i class="fas fa-receipt"></i>
        </div>
        <div class="stat-info">
            <h3><?php echo number_format($stats['today_transactions']); ?></h3>
            <p>Today's Transactions</p>
        </div>
    </div>
    <?php endif; ?>

    <div class="stat-card">
        <div class="stat-icon bg-orange">
            <i class="fas fa-exclamation-triangle"></i>
        </div>
        <div class="stat-info">
            <h3><?php echo number_format($stats['low_stock']); ?></h3>
            <p>Low Stock Items</p>
        </div>
    </div>
</div>

<div class="dashboard-row">
    <!-- Recent Transactions -->
    <?php if (in_array($current_role, ['admin', 'owner', 'accountant', 'manager', 'cashier'])): ?>
    <div class="card flex-grow">
        <div class="card-header">
            <h3><i class="fas fa-clock"></i> Recent Transactions</h3>
            <a href="<?php echo BASE_URL; ?>/modules/reports.php" class="btn btn-sm btn-outline">View All</a>
        </div>
        <div class="card-body">
            <?php if (empty($recent_transactions)): ?>
                <p class="text-muted text-center">No transactions yet today.</p>
            <?php else: ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Transaction #</th>
                            <th>Cashier</th>
                            <th>Amount</th>
                            <th>Method</th>
                            <th>Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recent_transactions as $txn): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($txn['transaction_no']); ?></strong></td>
                            <td><?php echo htmlspecialchars($txn['full_name'] ?? 'Unknown'); ?></td>
                            <td>₱<?php echo number_format($txn['grand_total'], 2); ?></td>
                            <td><span class="badge badge-<?php echo $txn['payment_method']; ?>"><?php echo ucfirst($txn['payment_method']); ?></span></td>
                            <td><?php echo date('h:i A', strtotime($txn['created_at'])); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- Low Stock Alerts -->
    <?php if (in_array($current_role, ['admin', 'owner', 'manager', 'inventory', 'warehouse'])): ?>
    <div class="card <?php echo !in_array($current_role, ['admin', 'owner', 'accountant', 'manager', 'cashier']) ? 'flex-grow' : ''; ?>">
        <div class="card-header">
            <h3><i class="fas fa-exclamation-triangle"></i> Low Stock Alerts</h3>
        </div>
        <div class="card-body">
            <?php if (empty($low_stock_products)): ?>
                <p class="text-muted text-center">All products are well stocked!</p>
            <?php else: ?>
                <div class="alert-list">
                    <?php foreach ($low_stock_products as $product): ?>
                    <div class="alert-item">
                        <div class="alert-item-info">
                            <strong><?php echo htmlspecialchars($product['name']); ?></strong>
                            <span><?php echo htmlspecialchars($product['category_name'] ?? 'Uncategorized'); ?></span>
                        </div>
                        <div class="alert-item-stock">
                            <span class="stock-low"><?php echo $product['stock']; ?> left</span>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- Quick Actions -->
<div class="card mt-3">
    <div class="card-header">
        <h3><i class="fas fa-bolt"></i> Quick Actions</h3>
    </div>
    <div class="card-body">
        <div class="quick-actions">
            <?php if (in_array('checkout', $allowed_pages)): ?>
            <a href="<?php echo BASE_URL; ?>/modules/checkout.php" class="action-btn">
                <i class="fas fa-shopping-cart"></i>
                <span>New Sale</span>
            </a>
            <?php endif; ?>
            
            <?php if (in_array('products', $allowed_pages)): ?>
            <a href="<?php echo BASE_URL; ?>/modules/products.php?action=add" class="action-btn">
                <i class="fas fa-plus"></i>
                <span>Add Product</span>
            </a>
            <?php endif; ?>

            <?php if (in_array('inventory', $allowed_pages)): ?>
            <a href="<?php echo BASE_URL; ?>/modules/inventory.php" class="action-btn">
                <i class="fas fa-boxes"></i>
                <span>View Inventory</span>
            </a>
            <?php endif; ?>

            <?php if (in_array('warehouse', $allowed_pages)): ?>
            <a href="<?php echo BASE_URL; ?>/modules/warehouse.php" class="action-btn">
                <i class="fas fa-warehouse"></i>
                <span>Warehouse</span>
            </a>
            <?php endif; ?>

            <?php if (in_array('reports', $allowed_pages)): ?>
            <a href="<?php echo BASE_URL; ?>/modules/reports.php" class="action-btn">
                <i class="fas fa-chart-bar"></i>
                <span>Reports</span>
            </a>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
