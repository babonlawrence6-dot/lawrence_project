</div><!-- /.content-wrapper -->
        </main>
    </div><!-- /.app-container -->

    <script src="<?php echo BASE_URL; ?>/js/app.js"></script>
</body>
</html>
