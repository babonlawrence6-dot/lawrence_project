<?php
// ============================================================
// POS System - Listing Helper (pagination + sorting + search)
// ============================================================
// Small, dependency-free toolkit shared by every module that lists an
// arbitrary number of rows (products, inventory, users, deliveries,
// report transaction lists, ...): page size, page navigation, sortable
// column headers, and a search box, all composing together through the
// query string.
//
// Usage:
//   require_once __DIR__ . '/../includes/pagination.php';
//   $per_page = get_per_page();
//   $page     = get_current_page();
//   $search   = get_search_query();
//   $sort_columns = ['name' => 'p.name', 'price' => 'p.price'];
//   $sort = get_sort_column($sort_columns, 'name');
//   $dir  = get_sort_direction();
//   // build WHERE using $search, ORDER BY using $sort_columns[$sort] and $dir
//   render_search_box($search, 'Search products...');
//   // in each <th>, call render_sort_link('Name', 'name', $sort, $dir)
//   render_pagination($page, $total, $per_page);
//   render_per_page_selector($per_page);
// ============================================================
// NOTE: never write a literal PHP closing tag inside a // comment
// anywhere in this file - PHP ends the comment (and PHP mode) right
// there, which is exactly the bug that broke this file once already.

/**
 * Read + sanitize the current page number from the query string (?p=).
 */
function get_current_page(): int {
    $page = isset($_GET['p']) ? (int)$_GET['p'] : 1;
    return $page > 0 ? $page : 1;
}

/**
 * Convert a page number into a SQL OFFSET.
 */
function get_pagination_offset(int $page, int $per_page): int {
    return ($page - 1) * $per_page;
}

/** Allowed "results per page" choices shown by render_per_page_selector(). */
const PAGINATION_PER_PAGE_OPTIONS = [10, 15, 25, 50, 100];

/**
 * Read + sanitize the "how many results per page" choice from the query
 * string (?per_page=). Falls back to $default if missing/invalid.
 */
function get_per_page(int $default = 15): int {
    $value = isset($_GET['per_page']) ? (int)$_GET['per_page'] : $default;
    return in_array($value, PAGINATION_PER_PAGE_OPTIONS, true) ? $value : $default;
}

/**
 * Render a "Show [10/15/25/50/100] per page" control. Submits via GET,
 * preserving every other query-string param already on the page, and
 * resets back to page 1 (a stale ?p= from a larger page count would
 * otherwise point past the end of the newly-sized result set).
 */
function render_per_page_selector(int $current): void {
    $params = $_GET;
    unset($params['p'], $params['per_page']);
    ?>
    <form method="GET" class="per-page-form">
        <?php foreach ($params as $key => $value): ?>
            <?php if (!is_scalar($value)) continue; ?>
            <input type="hidden" name="<?php echo htmlspecialchars($key); ?>" value="<?php echo htmlspecialchars((string)$value); ?>">
        <?php endforeach; ?>
        <label for="per_page" class="per-page-label">Show</label>
        <select id="per_page" name="per_page" onchange="this.form.submit()">
            <?php foreach (PAGINATION_PER_PAGE_OPTIONS as $option): ?>
                <option value="<?php echo $option; ?>" <?php echo $option === $current ? 'selected' : ''; ?>><?php echo $option; ?></option>
            <?php endforeach; ?>
        </select>
        <span class="per-page-label">per page</span>
    </form>
    <?php
}

/**
 * Render page links + a "Showing X-Y of Z" summary, preserving every
 * other query-string param already on the page (filters, report type,
 * search terms, etc.) so pagination composes with them automatically.
 */
function render_pagination(int $page, int $total_rows, int $per_page): void {
    if ($total_rows <= 0) {
        return; // nothing to count or page through
    }

    $total_pages = (int)ceil($total_rows / max(1, $per_page));
    $page = max(1, min($page, $total_pages));

    $params = $_GET;
    $build_url = function (int $p) use ($params) {
        $params['p'] = $p;
        return '?' . http_build_query($params);
    };

    $window = 2; // how many page numbers to show on each side of the current page
    ?>
    <div class="pagination-wrap">
        <?php if ($total_pages > 1): ?>
        <nav class="pagination" aria-label="Pagination">
            <?php if ($page > 1): ?>
                <a href="<?php echo htmlspecialchars($build_url($page - 1)); ?>" class="pagination-btn" aria-label="Previous page">
                    <i class="fas fa-chevron-left"></i>
                </a>
            <?php else: ?>
                <span class="pagination-btn disabled"><i class="fas fa-chevron-left"></i></span>
            <?php endif; ?>

            <?php
            $last_shown = 0;
            for ($i = 1; $i <= $total_pages; $i++):
                $show = ($i === 1 || $i === $total_pages || ($i >= $page - $window && $i <= $page + $window));
                if (!$show) {
                    continue;
                }
                if ($last_shown && $i - $last_shown > 1):
            ?>
                <span class="pagination-ellipsis">&hellip;</span>
            <?php
                endif;
                $last_shown = $i;
            ?>
                <a href="<?php echo htmlspecialchars($build_url($i)); ?>"
                   class="pagination-btn <?php echo $i === $page ? 'active' : ''; ?>"
                   <?php echo $i === $page ? 'aria-current="page"' : ''; ?>><?php echo $i; ?></a>
            <?php endfor; ?>

            <?php if ($page < $total_pages): ?>
                <a href="<?php echo htmlspecialchars($build_url($page + 1)); ?>" class="pagination-btn" aria-label="Next page">
                    <i class="fas fa-chevron-right"></i>
                </a>
            <?php else: ?>
                <span class="pagination-btn disabled"><i class="fas fa-chevron-right"></i></span>
            <?php endif; ?>
        </nav>
        <?php endif; ?>
        <p class="pagination-summary">
            Showing <?php echo number_format(min($total_rows, ($page - 1) * $per_page + 1)); ?>&ndash;<?php echo number_format(min($total_rows, $page * $per_page)); ?>
            of <?php echo number_format($total_rows); ?>
        </p>
    </div>
    <?php
}

/**
 * Read + validate the sort column against a whitelist map of
 * column-key => real SQL expression (e.g. ['name' => 'p.name']).
 * Only ever returns a key that exists in $allowed, so the caller can
 * safely interpolate $allowed[$sort] into an ORDER BY clause - the
 * value never comes from user input directly.
 */
function get_sort_column(array $allowed, string $default): string {
    $col = $_GET['sort'] ?? $default;
    return array_key_exists($col, $allowed) ? $col : $default;
}

/**
 * Read + validate the sort direction from the query string (?dir=).
 */
function get_sort_direction(string $default = 'ASC'): string {
    $dir = strtoupper((string)($_GET['dir'] ?? $default));
    return $dir === 'DESC' ? 'DESC' : 'ASC';
}

/**
 * Render a sortable column header link. Clicking it sorts by $column,
 * flipping ASC/DESC if it's already the active column, and resets back
 * to page 1 (a stale ?p= could point past the end once the order
 * changes what lands on each page).
 */
function render_sort_link(string $label, string $column, string $current_sort, string $current_dir): void {
    $params = $_GET;
    $next_dir = ($current_sort === $column && $current_dir === 'ASC') ? 'DESC' : 'ASC';
    $params['sort'] = $column;
    $params['dir'] = strtolower($next_dir);
    $params['p'] = 1;
    $is_active = $current_sort === $column;
    $icon = 'fa-sort';
    if ($is_active) {
        $icon = $current_dir === 'ASC' ? 'fa-sort-up' : 'fa-sort-down';
    }
    ?><a href="?<?php echo htmlspecialchars(http_build_query($params)); ?>" class="sortable-th <?php echo $is_active ? 'active' : ''; ?>"><?php echo htmlspecialchars($label); ?> <i class="fas <?php echo $icon; ?>"></i></a><?php
}

/**
 * Read + sanitize the current search term from the query string (?q=).
 */
function get_search_query(): string {
    return trim((string)($_GET['q'] ?? ''));
}

/**
 * Render a search box. Submits via GET, preserving every other
 * query-string param already on the page (page size, sort, filters,
 * ...) and resetting back to page 1.
 */
function render_search_box(string $current, string $placeholder = 'Search...'): void {
    $params = $_GET;
    unset($params['q'], $params['p']);
    ?>
    <form method="GET" class="listing-search">
        <?php foreach ($params as $key => $value): ?>
            <?php if (!is_scalar($value)) continue; ?>
            <input type="hidden" name="<?php echo htmlspecialchars($key); ?>" value="<?php echo htmlspecialchars((string)$value); ?>">
        <?php endforeach; ?>
        <div class="search-input-wrap">
            <i class="fas fa-search"></i>
            <input type="text" name="q" value="<?php echo htmlspecialchars($current); ?>" placeholder="<?php echo htmlspecialchars($placeholder); ?>">
            <?php if ($current !== ''): ?>
                <a href="?<?php echo htmlspecialchars(http_build_query($params)); ?>" class="search-clear" title="Clear search"><i class="fas fa-times"></i></a>
            <?php endif; ?>
        </div>
    </form>
    <?php
}
