<?php
// ============================================================
// POS System - Database Configuration
// ============================================================

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'pos_db');

date_default_timezone_set('Asia/Manila');

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );
    $pdo->exec("SET time_zone = '+08:00'");
} catch (PDOException $e) {
    die("Database connection failed. Please check your database configuration.");
}

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'httponly' => true,
        'samesite' => 'Lax',
        'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'
    ]);
    session_start();
}

define('SITE_NAME', 'SEVEN EVELYN');
$script_directory = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/'));
if (basename($script_directory) === 'modules') {
    $script_directory = dirname($script_directory);
}
define('BASE_URL', rtrim($script_directory, '/'));

/** Return an uploaded product image or a local product/category photo fallback. */
function product_image_url(array $product): string {
    $image_name = strtolower(trim((string)($product['name'] ?? '')));
    $image_name = trim((string)preg_replace('/[^a-z0-9]+/', '-', $image_name), '-');
    $product_art = 'product-' . $image_name . '.svg';
    $has_product_art = $image_name !== '' && is_file(__DIR__ . '/../uploads/' . $product_art);
    $product_photo = 'product-' . $image_name . '.jpg';
    $has_product_photo = $image_name !== '' && is_file(__DIR__ . '/../uploads/' . $product_photo);

    if (!empty($product['image'])) {
        $stored_image = basename($product['image']);
        if ($has_product_photo && strtolower($stored_image) === $image_name . '.svg') {
            return BASE_URL . '/uploads/' . rawurlencode($product_photo);
        }
        return BASE_URL . '/uploads/' . rawurlencode($stored_image);
    }

    if ($has_product_photo) {
        return BASE_URL . '/uploads/' . rawurlencode($product_photo);
    }

    if ($has_product_art) {
        return BASE_URL . '/uploads/' . rawurlencode($product_art);
    }

    $category = strtolower((string)($product['category_name'] ?? ''));
    $fallbacks = [
        'beverages' => 'photo-1544145945-f90425340c7e',
        'snacks' => 'photo-1621939514649-280e2aa6f7e3',
        'dairy' => 'photo-1550583724-b2692b85b150',
        'bakery' => 'photo-1509440159596-0249088772ff',
        'frozen' => 'photo-1579751626657-72bc17010498',
        'household' => 'photo-1583947215259-38e31be8751f'
    ];
    $photo_id = $fallbacks[$category] ?? 'photo-1542838132-92c53300491e';
    return 'https://images.unsplash.com/' . $photo_id . '?auto=format&fit=crop&w=640&h=480&q=85';
}

if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

function csrf_token(): string {
    return $_SESSION['csrf_token'];
}

function verify_csrf(): void {
    $token = $_POST['csrf_token'] ?? '';
    if (!is_string($token) || !hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
        http_response_code(403);
        exit('Invalid security token. Please refresh the page and try again.');
    }
}

/** Record every inventory movement for audit/history purposes. */
function record_stock_movement(PDO $pdo, int $productId, int $quantityChange, string $movementType, ?string $referenceNo = null, ?int $userId = null, ?string $location = 'Main Store', ?string $notes = null): void {
    if ($quantityChange === 0) return;
    $stmt = $pdo->prepare("INSERT INTO stock_movements (product_id, movement_type, quantity_change, reference_no, user_id, location, notes) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$productId, $movementType, $quantityChange, $referenceNo, $userId, $location, $notes]);
}

function get_current_user_id(): int {
    return (int)($_SESSION['user_id'] ?? 0);
}

/** Require an authenticated user with one of the supplied roles. */
function require_role(PDO $pdo, array $roles): void {
    enforce_active_session($pdo);
    if (!isset($_SESSION['user_id'])) {
        header('Location: ' . BASE_URL . '/index.php');
        exit;
    }
    $role = $_SESSION['user_role'] ?? '';
    if (!in_array($role, $roles, true)) {
        http_response_code(403);
        exit('Access denied. Your account is not allowed to use this module.');
    }
}

function enforce_active_session(PDO $pdo): void {
    if (!isset($_SESSION['user_id'])) return;
    try {
        $stmt = $pdo->prepare('SELECT username, full_name, role, status FROM users WHERE id = ?');
        $stmt->execute([(int)$_SESSION['user_id']]);
        $user = $stmt->fetch();
        if (!$user || $user['status'] !== 'active') {
            $_SESSION = [];
            if (ini_get('session.use_cookies')) {
                $params = session_get_cookie_params();
                setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
            }
            session_destroy();
            header('Location: ' . BASE_URL . '/index.php?inactive=1');
            exit;
        }
        $_SESSION['username'] = $user['username'];
        $_SESSION['user_name'] = $user['full_name'];
        $_SESSION['user_role'] = $user['role'];
    } catch (PDOException $e) {
        // Keep the session if the database temporarily cannot be checked.
    }
}

enforce_active_session($pdo);
