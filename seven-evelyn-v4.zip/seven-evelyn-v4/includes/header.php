<?php
require_once __DIR__ . '/config.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/index.php');
    exit;
}

$current_user = $_SESSION['user_name'] ?? 'Unknown';
$current_role = $_SESSION['user_role'] ?? 'cashier';
$current_page = basename($_SERVER['PHP_SELF'], '.php');

// Define Access Permissions for each role
$permissions = [
    'admin'      => ['dashboard', 'products', 'inventory', 'checkout', 'reports', 'users', 'warehouse'],
    'owner'      => ['dashboard', 'reports', 'products', 'inventory', 'warehouse'],
    'manager'    => ['dashboard', 'reports', 'inventory', 'products'],
    'cashier'    => ['dashboard', 'checkout', 'reports'],
    'inventory'  => ['dashboard', 'inventory', 'products'],
    'warehouse'  => ['dashboard', 'warehouse', 'inventory'],
    'accountant' => ['dashboard', 'reports']
];

$allowed_pages = $permissions[$current_role] ?? ['dashboard'];

// Check page permission
if (!in_array($current_page, $allowed_pages) && $current_page !== 'logout') {
    $_SESSION['error_msg'] = "Access Denied: You do not have permission to access this module.";
    header('Location: ' . BASE_URL . '/dashboard.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle ?? SITE_NAME; ?></title>
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/css/style.css?v=20261029-supermarket-checkout-v2">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
</head>
<body>
    <div class="app-container">
        <!-- Sidebar Navigation -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <h2><i class="fas fa-cash-register"></i> Seven Evelyn</h2>
            </div>
            <nav class="sidebar-nav">
                <a href="<?php echo BASE_URL; ?>/dashboard.php" class="nav-item <?php echo $current_page === 'dashboard' ? 'active' : ''; ?>">
                    <i class="fas fa-home"></i> <span>Dashboard</span>
                </a>

                <?php if (in_array('checkout', $allowed_pages)): ?>
                <a href="<?php echo BASE_URL; ?>/modules/checkout.php" class="nav-item <?php echo $current_page === 'checkout' ? 'active' : ''; ?>">
                    <i class="fas fa-shopping-cart"></i> <span>Sales / Checkout</span>
                </a>
                <?php endif; ?>

                <?php if (in_array('products', $allowed_pages)): ?>
                <a href="<?php echo BASE_URL; ?>/modules/products.php" class="nav-item <?php echo $current_page === 'products' ? 'active' : ''; ?>">
                    <i class="fas fa-box"></i> <span>Product Management</span>
                </a>
                <?php endif; ?>

                <?php if (in_array('inventory', $allowed_pages)): ?>
                <a href="<?php echo BASE_URL; ?>/modules/inventory.php" class="nav-item <?php echo $current_page === 'inventory' ? 'active' : ''; ?>">
                    <i class="fas fa-boxes"></i> <span>Inventory</span>
                </a>
                <?php endif; ?>

                <?php if (in_array('warehouse', $allowed_pages)): ?>
                <a href="<?php echo BASE_URL; ?>/modules/warehouse.php" class="nav-item <?php echo $current_page === 'warehouse' ? 'active' : ''; ?>">
                    <i class="fas fa-warehouse"></i> <span>Warehouse</span>
                </a>
                <?php endif; ?>

                <?php if (in_array('reports', $allowed_pages)): ?>
                <a href="<?php echo BASE_URL; ?>/modules/reports.php" class="nav-item <?php echo $current_page === 'reports' ? 'active' : ''; ?>">
                    <i class="fas fa-chart-bar"></i> <span>Reports</span>
                </a>
                <?php endif; ?>

                <?php if (in_array('users', $allowed_pages)): ?>
                <a href="<?php echo BASE_URL; ?>/modules/users.php" class="nav-item <?php echo $current_page === 'users' ? 'active' : ''; ?>">
                    <i class="fas fa-users-cog"></i> <span>User Management</span>
                </a>
                <?php endif; ?>
            </nav>
            <div class="sidebar-footer">
                <div class="user-info">
                    <i class="fas fa-user-circle"></i>
                    <div>
                        <strong><?php echo htmlspecialchars($current_user); ?></strong>
                        <small><?php echo ucfirst($current_role); ?></small>
                    </div>
                </div>
                <a href="<?php echo BASE_URL; ?>/logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
                </a>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <header class="top-bar">
                <button class="menu-toggle" id="menuToggle">
                    <i class="fas fa-bars"></i>
                </button>
                <h1 class="page-title"><?php echo $pageTitle ?? 'Dashboard'; ?></h1>
                <div class="top-actions">
                    <span class="date-display"><?php echo date('l, F j, Y'); ?></span>
                </div>
            </header>
            
            <?php if (isset($_SESSION['error_msg'])): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-triangle"></i>
                <?php echo $_SESSION['error_msg']; unset($_SESSION['error_msg']); ?>
            </div>
            <?php endif; ?>

            <div class="content-wrapper">
