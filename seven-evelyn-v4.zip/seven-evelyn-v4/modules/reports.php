<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/pagination.php';

require_role($pdo, ['admin', 'owner', 'manager', 'cashier', 'accountant']);

$pageTitle = 'Reports';

// Determine report type
$report_type = $_GET['type'] ?? 'daily';

// Fetch report data based on type
$transactions = [];
$total_revenue = 0;
$total_discount = 0;
$total_cost = 0;
$total_profit = 0;
$total_transactions_count = 0;
$chart_data = [];

// Pagination only applies to the per-transaction listing tables
// (daily/weekly/monthly) - the stat cards and charts above the table
// always reflect the whole period; search/sort only affect the
// Transaction Details table (and its own row count) below it.
$per_page = get_per_page();
$page = get_current_page();
$search = get_search_query();
$filtered_transactions_count = 0;

$txn_sort_columns = [
    'transaction_no' => 't.transaction_no',
    'full_name'      => 'u.full_name',
    'discount'       => 't.discount',
    'grand_total'    => 't.grand_total',
    'payment_method' => 't.payment_method',
    'created_at'     => 't.created_at',
];
$txn_sort = get_sort_column($txn_sort_columns, 'created_at');
$txn_dir = get_sort_direction('DESC');

$search_sql = '';
$search_params = [];
if ($search !== '') {
    // Native (non-emulated) prepares can't reuse the same named
    // placeholder more than once per query, so each LIKE gets its own.
    $search_sql = "AND (t.transaction_no LIKE :q1 OR u.full_name LIKE :q2 OR t.payment_method LIKE :q3)";
    $like = '%' . $search . '%';
    $search_params = [':q1' => $like, ':q2' => $like, ':q3' => $like];
}

switch ($report_type) {
    case 'daily':
        $date_where = "DATE(t.created_at) = CURDATE() AND t.status = 'completed'";

        $agg = $pdo->query("SELECT COUNT(*) as cnt, COALESCE(SUM(grand_total),0) as revenue, COALESCE(SUM(discount),0) as discount FROM transactions WHERE DATE(created_at) = CURDATE() AND status = 'completed'")->fetch();
        $total_transactions_count = (int)$agg['cnt'];
        $total_revenue = (float)$agg['revenue'];
        $total_discount = (float)$agg['discount'];

        $count_stmt = $pdo->prepare("SELECT COUNT(*) FROM transactions t LEFT JOIN users u ON t.user_id = u.id WHERE $date_where $search_sql");
        $count_stmt->execute($search_params);
        $filtered_transactions_count = (int)$count_stmt->fetchColumn();

        $stmt = $pdo->prepare("SELECT t.*, u.full_name FROM transactions t LEFT JOIN users u ON t.user_id = u.id WHERE $date_where $search_sql ORDER BY {$txn_sort_columns[$txn_sort]} $txn_dir LIMIT :limit OFFSET :offset");
        foreach ($search_params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        $stmt->bindValue(':limit', $per_page, PDO::PARAM_INT);
        $stmt->bindValue(':offset', get_pagination_offset($page, $per_page), PDO::PARAM_INT);
        $stmt->execute();
        $transactions = $stmt->fetchAll();

        // Daily chart - hourly breakdown
        $stmt = $pdo->query("SELECT HOUR(created_at) as hour, COUNT(*) as count, SUM(grand_total) as total FROM transactions WHERE DATE(created_at) = CURDATE() AND status = 'completed' GROUP BY HOUR(created_at)");
        $hourly = $stmt->fetchAll();
        $hours = array_fill(0, 24, 0);
        $hourly_totals = array_fill(0, 24, 0);
        foreach ($hourly as $h) {
            $hours[$h['hour']] = (int)$h['count'];
            $hourly_totals[$h['hour']] = (float)$h['total'];
        }
        $chart_data = [
            'labels' => range(0, 23),
            'datasets' => [
                ['label' => 'Transactions', 'data' => $hours],
                ['label' => 'Revenue ($)', 'data' => $hourly_totals]
            ]
        ];
        break;

    case 'weekly':
        $date_where = "t.created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND t.status = 'completed'";

        $agg = $pdo->query("SELECT COUNT(*) as cnt, COALESCE(SUM(grand_total),0) as revenue, COALESCE(SUM(discount),0) as discount FROM transactions WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND status = 'completed'")->fetch();
        $total_transactions_count = (int)$agg['cnt'];
        $total_revenue = (float)$agg['revenue'];
        $total_discount = (float)$agg['discount'];

        $count_stmt = $pdo->prepare("SELECT COUNT(*) FROM transactions t LEFT JOIN users u ON t.user_id = u.id WHERE $date_where $search_sql");
        $count_stmt->execute($search_params);
        $filtered_transactions_count = (int)$count_stmt->fetchColumn();

        $stmt = $pdo->prepare("SELECT t.*, u.full_name FROM transactions t LEFT JOIN users u ON t.user_id = u.id WHERE $date_where $search_sql ORDER BY {$txn_sort_columns[$txn_sort]} $txn_dir LIMIT :limit OFFSET :offset");
        foreach ($search_params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        $stmt->bindValue(':limit', $per_page, PDO::PARAM_INT);
        $stmt->bindValue(':offset', get_pagination_offset($page, $per_page), PDO::PARAM_INT);
        $stmt->execute();
        $transactions = $stmt->fetchAll();

        // Weekly chart - daily breakdown
        $stmt = $pdo->query("SELECT DATE(created_at) as day, COUNT(*) as count, SUM(grand_total) as total FROM transactions WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND status = 'completed' GROUP BY DATE(created_at) ORDER BY day");
        $daily = $stmt->fetchAll();
        $days = [];
        $day_totals = [];
        foreach ($daily as $d) {
            $days[] = date('M j', strtotime($d['day']));
            $day_totals[] = (float)$d['total'];
        }
        $chart_data = [
            'labels' => $days,
            'datasets' => [
                ['label' => 'Revenue ($)', 'data' => $day_totals]
            ]
        ];
        break;

    case 'monthly':
        $date_where = "t.created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) AND t.status = 'completed'";

        $agg = $pdo->query("SELECT COUNT(*) as cnt, COALESCE(SUM(grand_total),0) as revenue, COALESCE(SUM(discount),0) as discount FROM transactions WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) AND status = 'completed'")->fetch();
        $total_transactions_count = (int)$agg['cnt'];
        $total_revenue = (float)$agg['revenue'];
        $total_discount = (float)$agg['discount'];

        $count_stmt = $pdo->prepare("SELECT COUNT(*) FROM transactions t LEFT JOIN users u ON t.user_id = u.id WHERE $date_where $search_sql");
        $count_stmt->execute($search_params);
        $filtered_transactions_count = (int)$count_stmt->fetchColumn();

        $stmt = $pdo->prepare("SELECT t.*, u.full_name FROM transactions t LEFT JOIN users u ON t.user_id = u.id WHERE $date_where $search_sql ORDER BY {$txn_sort_columns[$txn_sort]} $txn_dir LIMIT :limit OFFSET :offset");
        foreach ($search_params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        $stmt->bindValue(':limit', $per_page, PDO::PARAM_INT);
        $stmt->bindValue(':offset', get_pagination_offset($page, $per_page), PDO::PARAM_INT);
        $stmt->execute();
        $transactions = $stmt->fetchAll();

        // Monthly chart - daily breakdown
        $stmt = $pdo->query("SELECT DATE(created_at) as day, COUNT(*) as count, SUM(grand_total) as total FROM transactions WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) AND status = 'completed' GROUP BY DATE(created_at) ORDER BY day");
        $daily = $stmt->fetchAll();
        $days = [];
        $day_totals = [];
        foreach ($daily as $d) {
            $days[] = date('M j', strtotime($d['day']));
            $day_totals[] = (float)$d['total'];
        }
        $chart_data = [
            'labels' => $days,
            'datasets' => [
                ['label' => 'Revenue ($)', 'data' => $day_totals]
            ]
        ];
        break;

    case 'best_selling':
        // Best selling products
        $stmt = $pdo->query("SELECT p.name, SUM(ti.quantity) as total_sold, SUM(ti.subtotal) as total_revenue FROM transaction_items ti JOIN transactions t ON t.id=ti.transaction_id JOIN products p ON ti.product_id = p.id WHERE t.status='completed' GROUP BY ti.product_id ORDER BY total_sold DESC LIMIT 20");
        $best_selling = $stmt->fetchAll();
        $chart_data = [
            'labels' => array_map(fn($r) => $r['name'], $best_selling),
            'datasets' => [
                ['label' => 'Units Sold', 'data' => array_map(fn($r) => (int)$r['total_sold'], $best_selling)]
            ]
        ];
        break;

    case 'by_cashier':
        // Sales by cashier
        $stmt = $pdo->query("SELECT u.full_name, COUNT(t.id) as transactions, SUM(t.grand_total) as total_revenue FROM transactions t JOIN users u ON t.user_id = u.id WHERE t.status = 'completed' GROUP BY t.user_id ORDER BY total_revenue DESC");
        $by_cashier = $stmt->fetchAll();
        $chart_data = [
            'labels' => array_map(fn($r) => $r['full_name'], $by_cashier),
            'datasets' => [
                ['label' => 'Revenue ($)', 'data' => array_map(fn($r) => (float)$r['total_revenue'], $by_cashier)]
            ]
        ];
        break;

    case 'profit':
        // Profit report
        $stmt = $pdo->query("SELECT ti.transaction_id, ti.product_id, ti.quantity, ti.unit_price, ti.subtotal, ti.cost_price, t.grand_total FROM transaction_items ti JOIN transactions t ON ti.transaction_id=t.id WHERE t.status='completed'");
        $items = $stmt->fetchAll();
        foreach ($items as $item) {
            $total_cost += (float)$item['cost_price'] * (int)$item['quantity'];
        }
        $revenue_stmt = $pdo->query("SELECT COALESCE(SUM(grand_total),0) FROM transactions WHERE status='completed'");
        $total_revenue = (float)$revenue_stmt->fetchColumn();
        $total_profit = $total_revenue - $total_cost;

        // Profit chart - monthly
        $stmt = $pdo->query("SELECT DATE_FORMAT(t.created_at, '%Y-%m') as month, SUM(t.grand_total) as revenue FROM transactions t WHERE t.status = 'completed' GROUP BY DATE_FORMAT(t.created_at, '%Y-%m') ORDER BY month");
        $monthly = $stmt->fetchAll();
        $months = [];
        $month_revenues = [];
        foreach ($monthly as $m) {
            $months[] = $m['month'];
            $month_revenues[] = (float)$m['revenue'];
        }
        $chart_data = [
            'labels' => $months,
            'datasets' => [
                ['label' => 'Revenue ($)', 'data' => $month_revenues]
            ]
        ];
        break;
}

// Note: $total_revenue / $total_discount / $total_transactions_count for
// daily/weekly/monthly reports are computed via aggregate queries above
// (not by summing $transactions), since $transactions is now paginated.

require_once __DIR__ . '/../includes/header.php';
?>

<!-- Report Navigation -->
<div class="card mb-3">
    <div class="card-body">
        <div class="report-tabs">
            <a href="?type=daily" class="report-tab <?php echo $report_type === 'daily' ? 'active' : ''; ?>">
                <i class="fas fa-calendar-day"></i> Daily
            </a>
            <a href="?type=weekly" class="report-tab <?php echo $report_type === 'weekly' ? 'active' : ''; ?>">
                <i class="fas fa-calendar-week"></i> Weekly
            </a>
            <a href="?type=monthly" class="report-tab <?php echo $report_type === 'monthly' ? 'active' : ''; ?>">
                <i class="fas fa-calendar-alt"></i> Monthly
            </a>
            <a href="?type=best_selling" class="report-tab <?php echo $report_type === 'best_selling' ? 'active' : ''; ?>">
                <i class="fas fa-star"></i> Best Selling
            </a>
            <a href="?type=by_cashier" class="report-tab <?php echo $report_type === 'by_cashier' ? 'active' : ''; ?>">
                <i class="fas fa-users"></i> By Cashier
            </a>
            <a href="?type=profit" class="report-tab <?php echo $report_type === 'profit' ? 'active' : ''; ?>">
                <i class="fas fa-chart-line"></i> Profit
            </a>
        </div>
    </div>
</div>

<!-- Stats for period-based reports -->
<?php if (in_array($report_type, ['daily', 'weekly', 'monthly'])): ?>
<div class="dashboard-grid mb-3">
    <div class="stat-card">
        <div class="stat-icon bg-green"><i class="fas fa-money-bill-wave"></i></div>
        <div class="stat-info">
            <h3>₱<?php echo number_format($total_revenue, 2); ?></h3>
            <p>Total Revenue</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon bg-blue"><i class="fas fa-receipt"></i></div>
        <div class="stat-info">
            <h3><?php echo number_format($total_transactions_count); ?></h3>
            <p>Total Transactions</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon bg-orange"><i class="fas fa-tag"></i></div>
        <div class="stat-info">
            <h3>₱<?php echo number_format($total_discount, 2); ?></h3>
            <p>Total Discounts</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon bg-purple"><i class="fas fa-calculator"></i></div>
        <div class="stat-info">
            <h3>₱<?php echo $total_transactions_count > 0 ? number_format($total_revenue / $total_transactions_count, 2) : '0.00'; ?></h3>
            <p>Average Transaction</p>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if ($report_type === 'best_selling'): ?>
<div class="card mb-3">
    <div class="card-header">
        <h3><i class="fas fa-star"></i> Best Selling Products</h3>
    </div>
    <div class="card-body">
        <?php if (empty($best_selling)): ?>
            <p class="text-muted text-center">No sales data available yet.</p>
        <?php else: ?>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Product</th>
                        <th>Units Sold</th>
                        <th>Total Revenue</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($best_selling as $index => $product): ?>
                    <tr>
                        <td><?php echo $index + 1; ?></td>
                        <td><strong><?php echo htmlspecialchars($product['name']); ?></strong></td>
                        <td><?php echo $product['total_sold']; ?></td>
                        <td>₱<?php echo number_format($product['total_revenue'], 2); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>
<?php endif; ?>

<?php if ($report_type === 'by_cashier'): ?>
<div class="card mb-3">
    <div class="card-header">
        <h3><i class="fas fa-users"></i> Sales by Cashier</h3>
    </div>
    <div class="card-body">
        <?php if (empty($by_cashier)): ?>
            <p class="text-muted text-center">No sales data available yet.</p>
        <?php else: ?>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Cashier</th>
                        <th>Transactions</th>
                        <th>Total Revenue</th>
                        <th>Average</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($by_cashier as $index => $cashier): ?>
                    <tr>
                        <td><?php echo $index + 1; ?></td>
                        <td><strong><?php echo htmlspecialchars($cashier['full_name']); ?></strong></td>
                        <td><?php echo $cashier['transactions']; ?></td>
                        <td>₱<?php echo number_format($cashier['total_revenue'], 2); ?></td>
                        <td>₱<?php echo number_format($cashier['transactions'] > 0 ? $cashier['total_revenue'] / $cashier['transactions'] : 0, 2); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>
<?php endif; ?>

<?php if ($report_type === 'profit'): ?>
<div class="dashboard-grid mb-3">
    <div class="stat-card">
        <div class="stat-icon bg-green"><i class="fas fa-money-bill-wave"></i></div>
        <div class="stat-info">
            <h3>₱<?php echo number_format($total_revenue, 2); ?></h3>
            <p>Total Revenue</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon bg-orange"><i class="fas fa-money-bill-wave"></i></div>
        <div class="stat-info">
            <h3>₱<?php echo number_format($total_cost, 2); ?></h3>
            <p>Total Cost</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon bg-blue"><i class="fas fa-chart-line"></i></div>
        <div class="stat-info">
            <h3>₱<?php echo number_format($total_profit, 2); ?></h3>
            <p>Total Profit</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon bg-purple"><i class="fas fa-percentage"></i></div>
        <div class="stat-info">
            <h3><?php echo $total_revenue > 0 ? number_format(($total_profit / $total_revenue) * 100, 1) : '0.0'; ?>%</h3>
            <p>Profit Margin</p>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Chart -->
<?php if (!empty($chart_data)): ?>
<div class="card mb-3">
    <div class="card-header">
        <h3><i class="fas fa-chart-bar"></i> Report Chart</h3>
    </div>
    <div class="card-body">
        <canvas id="reportChart" height="300"></canvas>
    </div>
</div>
<?php endif; ?>

<!-- Transactions Table for period reports -->
<?php if (in_array($report_type, ['daily', 'weekly', 'monthly'])): ?>
<div class="card">
    <div class="card-header">
        <h3><i class="fas fa-list"></i> Transaction Details</h3>
        <div class="header-actions">
            <?php render_search_box($search, 'Search transactions...'); ?>
            <?php render_per_page_selector($per_page); ?>
        </div>
    </div>
    <div class="card-body">
        <?php if (empty($transactions)): ?>
            <p class="text-muted text-center">
                No transactions found<?php echo $search !== '' ? ' for "' . htmlspecialchars($search) . '"' : ' for this period'; ?>.
            </p>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th><?php render_sort_link('Transaction #', 'transaction_no', $txn_sort, $txn_dir); ?></th>
                            <th><?php render_sort_link('Cashier', 'full_name', $txn_sort, $txn_dir); ?></th>
                            <th>Items</th>
                            <th><?php render_sort_link('Discount', 'discount', $txn_sort, $txn_dir); ?></th>
                            <th><?php render_sort_link('Total', 'grand_total', $txn_sort, $txn_dir); ?></th>
                            <th><?php render_sort_link('Method', 'payment_method', $txn_sort, $txn_dir); ?></th>
                            <th><?php render_sort_link('Date/Time', 'created_at', $txn_sort, $txn_dir); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($transactions as $txn): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($txn['transaction_no']); ?></strong></td>
                            <td><?php echo htmlspecialchars($txn['full_name'] ?? 'Unknown'); ?></td>
                            <td>
                                <?php
                                $itemStmt = $pdo->prepare("SELECT COUNT(*) as cnt FROM transaction_items WHERE transaction_id = :tid");
                                $itemStmt->execute([':tid' => $txn['id']]);
                                echo $itemStmt->fetch()['cnt'] . ' items';
                                ?>
                            </td>
                            <td>₱<?php echo number_format($txn['discount'], 2); ?></td>
                            <td><strong>₱<?php echo number_format($txn['grand_total'], 2); ?></strong></td>
                            <td><span class="badge badge-<?php echo $txn['payment_method']; ?>"><?php echo ucfirst($txn['payment_method']); ?></span></td>
                            <td><?php echo date('M j, Y h:i A', strtotime($txn['created_at'])); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php render_pagination($page, $filtered_transactions_count, $per_page); ?>
        <?php endif; ?>
    </div>
</div>
<?php endif; ?>

<script>
<?php if (!empty($chart_data)): ?>
const chartConfig = <?php echo json_encode($chart_data); ?>;
const colors = ['#3498db', '#2ecc71', '#e74c3c', '#f39c12', '#9b59b6', '#1abc9c'];

const ctx = document.getElementById('reportChart').getContext('2d');
new Chart(ctx, {
    type: '<?php echo $report_type === 'best_selling' ? 'bar' : 'line'; ?>',
    data: {
        labels: chartConfig.labels,
        datasets: chartConfig.datasets.map((ds, i) => ({
            ...ds,
            borderColor: colors[i % colors.length],
            backgroundColor: colors[i % colors.length] + '40',
            fill: true,
            tension: 0.3,
            borderWidth: 2,
            pointRadius: 4
        }))
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: { display: true, position: 'top' }
        },
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: function(value) {
                        return '₱' + value;
                    }
                }
            }
        }
    }
});
<?php endif; ?>
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
