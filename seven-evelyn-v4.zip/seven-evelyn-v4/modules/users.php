<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/pagination.php';

// Only admin can access this module
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: ' . BASE_URL . '/dashboard.php');
    exit;
}

$pageTitle = 'User Management';
$message = '';
$message_type = '';
$action = $_GET['action'] ?? 'list';

$role_labels = [
    'admin' => 'Admin',
    'owner' => 'Business Owner',
    'manager' => 'Manager',
    'inventory' => 'Stock Clerk',
    'warehouse' => 'Warehouse Keeper',
    'accountant' => 'Accountant',
    'cashier' => 'Employee',
];

// ============================================================
// HANDLE ADD / EDIT USER (POST)
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_action'])) {
    verify_csrf();
    $user_action = $_POST['user_action'];

    $username = trim($_POST['username'] ?? '');
    $full_name = trim($_POST['full_name'] ?? '');
    $role = $_POST['role'] ?? 'cashier';
    $status = $_POST['status'] ?? 'active';
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    // Validation
    $errors = [];

    if (empty($username)) {
        $errors[] = 'Username is required.';
    } elseif (strlen($username) < 3) {
        $errors[] = 'Username must be at least 3 characters long.';
    } elseif (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
        $errors[] = 'Username can only contain letters, numbers, and underscores.';
    }

    if (empty($full_name)) {
        $errors[] = 'Full name is required.';
    }

    if (!in_array($role, array_keys($role_labels), true)) {
        $errors[] = 'Invalid role selected.';
    }

    if (!in_array($status, ['active', 'inactive'], true)) {
        $errors[] = 'Invalid account status selected.';
    }

    if ($user_action === 'add') {
        if (empty($password)) {
            $errors[] = 'Password is required for new users.';
        } elseif (strlen($password) < 6) {
            $errors[] = 'Password must be at least 6 characters long.';
        }
        if ($password !== $confirm_password) {
            $errors[] = 'Passwords do not match.';
        }

        // Check if username already exists
        if (empty($errors)) {
            $stmt = $pdo->prepare("SELECT id FROM users WHERE username = :username");
            $stmt->execute([':username' => $username]);
            if ($stmt->fetch()) {
                $errors[] = 'Username already exists. Please choose another.';
            }
        }

        if (empty($errors)) {
            try {
                $hashed_password = password_hash($password, PASSWORD_BCRYPT, ['cost' => 10]);
                $stmt = $pdo->prepare("INSERT INTO users (username, password, full_name, role, status) VALUES (:username, :password, :full_name, :role, :status)");
                $stmt->execute([
                    ':username' => $username,
                    ':password' => $hashed_password,
                    ':full_name' => $full_name,
                    ':role' => $role,
                    ':status' => $status
                ]);
                $message = 'User "' . htmlspecialchars($username) . '" has been created successfully!';
                $message_type = 'success';
            } catch (PDOException $e) {
                $errors[] = 'Database error: ' . $e->getMessage();
            }
        }
    }

    elseif ($user_action === 'edit') {
        $user_id = (int)($_POST['user_id'] ?? 0);

        // Prevent editing own account
        if ($user_id === (int)$_SESSION['user_id']) {
            $errors[] = 'You cannot edit your own account from this page. Use your profile settings.';
        }

        // Check if username already exists (for different user)
        if (empty($errors) && !empty($username)) {
            $stmt = $pdo->prepare("SELECT id FROM users WHERE username = :username AND id != :id");
            $stmt->execute([':username' => $username, ':id' => $user_id]);
            if ($stmt->fetch()) {
                $errors[] = 'Username already taken by another user.';
            }
        }

        if (empty($errors)) {
            try {
                if (!empty($password)) {
                    if (strlen($password) < 6) {
                        $errors[] = 'Password must be at least 6 characters long.';
                    }
                    if ($password !== $confirm_password) {
                        $errors[] = 'Passwords do not match.';
                    }
                }

                if (empty($errors)) {
                    if (!empty($password)) {
                        $hashed_password = password_hash($password, PASSWORD_BCRYPT, ['cost' => 10]);
                        $stmt = $pdo->prepare("UPDATE users SET username = :username, password = :password, full_name = :full_name, role = :role, status = :status WHERE id = :id");
                        $stmt->execute([
                            ':username' => $username,
                            ':password' => $hashed_password,
                            ':full_name' => $full_name,
                            ':role' => $role,
                            ':status' => $status,
                            ':id' => $user_id
                        ]);
                    } else {
                        $stmt = $pdo->prepare("UPDATE users SET username = :username, full_name = :full_name, role = :role, status = :status WHERE id = :id");
                        $stmt->execute([
                            ':username' => $username,
                            ':full_name' => $full_name,
                            ':role' => $role,
                            ':status' => $status,
                            ':id' => $user_id
                        ]);
                    }
                }

                if (empty($errors)) {
                    $message = 'User "' . htmlspecialchars($username) . '" has been updated successfully!';
                    $message_type = 'success';
                }
            } catch (PDOException $e) {
                $errors[] = 'Database error: ' . $e->getMessage();
            }
        }
    }

    if (!empty($errors)) {
        $message = implode('<br>', $errors);
        $message_type = 'error';
    } else {
        $action = 'list';
    }
}

// ============================================================
// HANDLE DELETE / ACTIVATE / DEACTIVATE USER (POST + CSRF)
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && (isset($_POST['delete_user']) || isset($_POST['toggle_status']))) {
    verify_csrf();
    $target_id = (int)($_POST['user_id'] ?? 0);

    if ($target_id <= 0 || $target_id === (int)$_SESSION['user_id']) {
        $message = 'You cannot modify your own account from these actions.';
        $message_type = 'error';
    } elseif (isset($_POST['delete_user'])) {
        try {
            // Preserve transaction/history references: deactivate instead of deleting users with history.
            $checks = [
                'transactions' => 'SELECT COUNT(*) FROM transactions WHERE user_id = ?',
                'deliveries' => 'SELECT COUNT(*) FROM deliveries WHERE received_by = ?',
                'transfers' => 'SELECT COUNT(*) FROM stock_transfers WHERE processed_by = ?'
            ];
            $has_history = false;
            foreach ($checks as $sql) {
                try {
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute([$target_id]);
                    if ((int)$stmt->fetchColumn() > 0) { $has_history = true; break; }
                } catch (PDOException $ignored) {
                    // Older databases may not have warehouse tables yet.
                }
            }

            if ($has_history) {
                $stmt = $pdo->prepare("UPDATE users SET status = 'inactive' WHERE id = ?");
                $stmt->execute([$target_id]);
                $message = 'User has transaction/history records, so the account was deactivated instead of deleted.';
            } else {
                $stmt = $pdo->prepare('DELETE FROM users WHERE id = ?');
                $stmt->execute([$target_id]);
                $message = $stmt->rowCount() ? 'User deleted successfully.' : 'User not found.';
            }
            $message_type = 'success';
        } catch (PDOException $e) {
            $message = 'Error updating user account.';
            $message_type = 'error';
        }
    } else {
        try {
            $stmt = $pdo->prepare('SELECT role, status FROM users WHERE id = ?');
            $stmt->execute([$target_id]);
            $target = $stmt->fetch();
            if (!$target) throw new RuntimeException('User not found.');

            if ($target['role'] === 'admin' && $target['status'] === 'active') {
                $stmt = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'admin' AND status = 'active'");
                if ((int)$stmt->fetchColumn() <= 1) {
                    throw new RuntimeException('You cannot deactivate the last active administrator.');
                }
            }

            $new_status = $target['status'] === 'active' ? 'inactive' : 'active';
            $stmt = $pdo->prepare('UPDATE users SET status = ? WHERE id = ?');
            $stmt->execute([$new_status, $target_id]);
            $message = 'User status changed to ' . $new_status . '.';
            $message_type = 'success';
        } catch (Throwable $e) {
            $message = $e instanceof RuntimeException ? $e->getMessage() : 'Error updating user status.';
            $message_type = 'error';
        }
    }
    $action = 'list';
}

// ============================================================
// FETCH DATA
// ============================================================

// Fetch all users for list view
$users = [];
$per_page = get_per_page();
$page = get_current_page();
$search = get_search_query();
$total_users = 0;

$user_sort_columns = [
    'username'   => 'username',
    'full_name'  => 'full_name',
    'role'       => 'role',
    'status'     => 'status',
    'created_at' => 'created_at',
];
$user_sort = get_sort_column($user_sort_columns, 'created_at');
$user_dir = get_sort_direction('DESC');

$user_where_sql = '';
$user_where_params = [];
if ($search !== '') {
    // Native (non-emulated) prepares can't reuse the same named
    // placeholder more than once per query, so each LIKE gets its own.
    $user_where_sql = 'WHERE (username LIKE :q1 OR full_name LIKE :q2 OR role LIKE :q3)';
    $like = '%' . $search . '%';
    $user_where_params = [':q1' => $like, ':q2' => $like, ':q3' => $like];
}

if ($action === 'list') {
    $count_stmt = $pdo->prepare("SELECT COUNT(*) FROM users $user_where_sql");
    $count_stmt->execute($user_where_params);
    $total_users = (int)$count_stmt->fetchColumn();

    $stmt = $pdo->prepare("SELECT * FROM users $user_where_sql ORDER BY {$user_sort_columns[$user_sort]} $user_dir LIMIT :limit OFFSET :offset");
    foreach ($user_where_params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    $stmt->bindValue(':limit', $per_page, PDO::PARAM_INT);
    $stmt->bindValue(':offset', get_pagination_offset($page, $per_page), PDO::PARAM_INT);
    $stmt->execute();
    $users = $stmt->fetchAll();
}

// Fetch single user for edit view
$user = null;
if ($action === 'edit' && isset($_GET['id'])) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id");
    $stmt->execute([':id' => (int)$_GET['id']]);
    $user = $stmt->fetch();

    if (!$user) {
        $message = 'User not found.';
        $message_type = 'error';
        $action = 'list';
    }
}

// Count stats
$stmt = $pdo->query("SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN role = 'admin' THEN 1 ELSE 0 END) as admins,
    SUM(CASE WHEN role = 'cashier' THEN 1 ELSE 0 END) as employees,
    SUM(CASE WHEN role = 'manager' THEN 1 ELSE 0 END) as managers,
    SUM(CASE WHEN role = 'inventory' THEN 1 ELSE 0 END) as stock_clerks,
    SUM(CASE WHEN role = 'accountant' THEN 1 ELSE 0 END) as accountants,
    SUM(CASE WHEN role = 'warehouse' THEN 1 ELSE 0 END) as warehouse_keepers,
    SUM(CASE WHEN role = 'owner' THEN 1 ELSE 0 END) as owners
FROM users");
$stats = $stmt->fetch();

require_once __DIR__ . '/../includes/header.php';
?>

<!-- Flash Messages -->
<?php if ($message): ?>
<div class="alert alert-<?php echo $message_type; ?> alert-dismissible">
    <i class="fas fa-<?php echo $message_type === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
    <div><?php echo $message; ?></div>
    <button class="close-btn" onclick="this.parentElement.remove()">&times;</button>
</div>
<?php endif; ?>

<?php if ($action === 'list'): ?>
<!-- ============================================================
     USER LIST VIEW
     ============================================================ -->

<!-- Stats Row -->
<div class="dashboard-grid mb-3">
    <div class="stat-card">
        <div class="stat-icon bg-blue"><i class="fas fa-users"></i></div>
        <div class="stat-info">
            <h3><?php echo (int)$stats['total']; ?></h3>
            <p>Total Users</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon bg-purple"><i class="fas fa-user-shield"></i></div>
        <div class="stat-info">
            <h3><?php echo (int)$stats['admins']; ?></h3>
            <p>Administrators</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon bg-green"><i class="fas fa-user-tag"></i></div>
        <div class="stat-info">
            <h3><?php echo (int)$stats['employees']; ?></h3>
            <p>Employees</p>
        </div>
    </div>
    <div class="stat-card" style="cursor: pointer;" onclick="window.location.href='?action=add'">
        <div class="stat-icon bg-orange"><i class="fas fa-user-plus"></i></div>
        <div class="stat-info">
            <h3>Add User</h3>
            <p>Create new account</p>
        </div>
    </div>
</div>

<!-- Users Table -->
<div class="card">
    <div class="card-header">
        <h3><i class="fas fa-users-cog"></i> User Accounts</h3>
        <div class="header-actions">
            <?php render_search_box($search, 'Search users...'); ?>
            <?php render_per_page_selector($per_page); ?>
            <a href="?action=add" class="btn btn-primary"><i class="fas fa-user-plus"></i> Add User</a>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th><?php render_sort_link('Username', 'username', $user_sort, $user_dir); ?></th>
                        <th><?php render_sort_link('Full Name', 'full_name', $user_sort, $user_dir); ?></th>
                        <th><?php render_sort_link('Role', 'role', $user_sort, $user_dir); ?></th>
                        <th><?php render_sort_link('Status', 'status', $user_sort, $user_dir); ?></th>
                        <th><?php render_sort_link('Date Created', 'created_at', $user_sort, $user_dir); ?></th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($users)): ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted" style="padding: 40px;">
                            <i class="fas fa-user-slash" style="font-size: 36px; opacity: 0.3; display: block; margin-bottom: 10px;"></i>
                            No users found<?php echo $search !== '' ? ' for "' . htmlspecialchars($search) . '"' : ''; ?>.
                        </td>
                    </tr>
                    <?php else: ?>
                    <?php foreach ($users as $index => $u): 
                        $is_current_user = ($u['id'] === (int)$_SESSION['user_id']);
                    ?>
                    <tr>
                        <td><?php echo $index + 1 + get_pagination_offset($page, $per_page); ?></td>
                        <td>
                            <strong><?php echo htmlspecialchars($u['username']); ?></strong>
                            <?php if ($is_current_user): ?>
                                <span class="badge badge-cash" style="background: var(--primary); color: #fff;">You</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo htmlspecialchars($u['full_name']); ?></td>
                        <td>
                            <?php if ($u['role'] === 'admin'): ?>
                                <span class="badge" style="background: #6c3baa; color: #fff;"><i class="fas fa-user-shield"></i> Admin</span>
                            <?php else: ?>
                                <span class="badge badge-cash"><i class="fas fa-user-tag"></i> <?php echo htmlspecialchars($role_labels[$u['role']] ?? ucfirst($u['role'])); ?></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="badge badge-<?php echo ($u['status'] ?? 'active') === 'active' ? 'success' : 'danger'; ?>">
                                <?php echo ucfirst($u['status'] ?? 'active'); ?>
                            </span>
                        </td>
                        <td><?php echo date('M j, Y', strtotime($u['created_at'])); ?></td>
                        <td>
                            <div style="display: flex; gap: 5px;">
                                <a href="?action=edit&id=<?php echo $u['id']; ?>" class="btn btn-sm btn-warning" title="Edit User">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form method="POST" style="display:<?php echo $is_current_user ? 'none' : 'inline'; ?>" onsubmit="return confirm('Toggle status for <?php echo htmlspecialchars($u['username'], ENT_QUOTES); ?>?')">
                                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrf_token()); ?>">
                                    <input type="hidden" name="user_id" value="<?php echo (int)$u['id']; ?>">
                                    <button type="submit" name="toggle_status" class="btn btn-sm btn-info" title="Toggle Status"><i class="fas fa-<?php echo ($u['status'] ?? 'active') === 'inactive' ? 'unlock' : 'lock'; ?>"></i></button>
                                </form>
                                <form method="POST" style="display:<?php echo $is_current_user ? 'none' : 'inline'; ?>" onsubmit="return confirm('Delete or deactivate this user account?')">
                                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrf_token()); ?>">
                                    <input type="hidden" name="user_id" value="<?php echo (int)$u['id']; ?>">
                                    <button type="submit" name="delete_user" class="btn btn-sm btn-danger" title="Delete User"><i class="fas fa-trash"></i></button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php render_pagination($page, $total_users, $per_page); ?>
    </div>
</div>

<?php elseif ($action === 'add' || $action === 'edit'): ?>
<!-- ============================================================
     ADD / EDIT USER FORM
     ============================================================ -->
<div class="card">
    <div class="card-header">
        <h3>
            <?php echo $user ? '<i class="fas fa-user-edit"></i> Edit User' : '<i class="fas fa-user-plus"></i> Add New User'; ?>
        </h3>
        <a href="?action=list" class="btn btn-outline"><i class="fas fa-arrow-left"></i> Back to List</a>
    </div>
    <div class="card-body">
        <form method="POST" id="userForm" class="form-horizontal">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrf_token()); ?>">
            <input type="hidden" name="user_action" value="<?php echo $user ? 'edit' : 'add'; ?>">
            <?php if ($user): ?>
            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
            <?php endif; ?>

            <div class="form-row">
                <div class="form-group">
                    <label for="username"><i class="fas fa-user"></i> Username *</label>
                    <input type="text" id="username" name="username" 
                           value="<?php echo htmlspecialchars($user['username'] ?? ''); ?>" 
                           placeholder="e.g., cashier2" required>
                    <small class="form-hint">Letters, numbers, and underscores only. Minimum 3 characters.</small>
                </div>
                <div class="form-group">
                    <label for="full_name"><i class="fas fa-id-card"></i> Full Name *</label>
                    <input type="text" id="full_name" name="full_name" 
                           value="<?php echo htmlspecialchars($user['full_name'] ?? ''); ?>" 
                           placeholder="e.g., Juan Dela Cruz" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="role"><i class="fas fa-shield-alt"></i> Role *</label>
                    <select id="role" name="role" required>
                        <option value="">-- Select Role --</option>
                        <?php foreach ($role_labels as $value => $label): ?>
                        <option value="<?php echo $value; ?>" <?php echo ($user && $user['role'] === $value) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($label); ?>
                        </option>
                    <?php endforeach; ?>
                    </select>
                    <small class="form-hint">Assign the appropriate role for this user.</small>
                </div>
                <div class="form-group">
                    <label for="status"><i class="fas fa-toggle-on"></i> Account Status *</label>
                    <select id="status" name="status" required>
                        <option value="active" <?php echo (($user && ($user['status'] ?? 'active') === 'active') || (!isset($user))) ? 'selected' : ''; ?>>Active</option>
                        <option value="inactive" <?php echo ($user && ($user['status'] ?? 'active') === 'inactive') ? 'selected' : ''; ?>>Inactive</option>
                    </select>
                    <small class="form-hint">Set whether the user account is active or not.</small>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="password">
                        <i class="fas fa-lock"></i> Password 
                        <?php echo $user ? '(Leave empty to keep current)' : '*'; ?>
                    </label>
                    <div class="password-wrapper">
                        <input type="password" id="password" name="password" 
                               <?php echo $user ? '' : 'required'; ?>
                               placeholder="<?php echo $user ? 'Enter new password (or leave empty)' : 'Minimum 6 characters'; ?>">
                        <button type="button" class="toggle-password" onclick="togglePassword('password')">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                </div>
                <div class="form-group">
                    <label for="confirm_password"><i class="fas fa-lock"></i> Confirm Password *</label>
                    <div class="password-wrapper">
                        <input type="password" id="confirm_password" name="confirm_password" 
                               placeholder="Re-enter password">
                        <button type="button" class="toggle-password" onclick="togglePassword('confirm_password')">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                </div>
            </div>

            <?php if ($user): ?>
            <div class="alert alert-warning" style="margin-bottom: 20px;">
                <i class="fas fa-info-circle"></i>
                <div>
                    You are editing user <strong><?php echo htmlspecialchars($user['username']); ?></strong>. 
                    Leave the password fields empty if you do not want to change the password.
                </div>
            </div>
            <?php endif; ?>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> <?php echo $user ? 'Update User' : 'Create User'; ?>
                </button>
                <a href="?action=list" class="btn btn-outline">Cancel</a>
            </div>
        </form>
    </div>
</div>

<!-- Password Strength Meter (Add only) -->
<?php if (!$user): ?>
<div class="card mt-3">
    <div class="card-header">
        <h3><i class="fas fa-info-circle"></i> Password Guidelines</h3>
    </div>
    <div class="card-body">
        <ul class="password-guidelines">
            <li><i class="fas fa-check-circle text-success"></i> Minimum 6 characters required</li>
            <li><i class="fas fa-check-circle text-success"></i> Use a mix of letters and numbers for better security</li>
            <li><i class="fas fa-check-circle text-success"></i> Avoid using common passwords like "123456" or "password"</li>
        </ul>
    </div>
</div>
<?php endif; ?>

<script>
// Toggle password visibility
function togglePassword(inputId) {
    const input = document.getElementById(inputId);
    const icon = input.nextElementSibling.querySelector('i');
    if (input.type === 'password') {
        input.type = 'text';
        icon.className = 'fas fa-eye-slash';
    } else {
        input.type = 'password';
        icon.className = 'fas fa-eye';
    }
}

// Client-side password match validation
document.getElementById('userForm').addEventListener('submit', function(e) {
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirm_password').value;

    if (password && password !== confirmPassword) {
        e.preventDefault();
        alert('Passwords do not match!');
        document.getElementById('confirm_password').focus();
        return false;
    }

    if (password && password.length < 6) {
        e.preventDefault();
        alert('Password must be at least 6 characters long!');
        document.getElementById('password').focus();
        return false;
    }
});
</script>

<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
