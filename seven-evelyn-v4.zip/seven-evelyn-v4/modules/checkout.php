<?php
require_once __DIR__ . '/../includes/config.php';

// Server-side authorization must happen before any POST action is processed.
require_role($pdo, ['admin', 'cashier']);

$pageTitle = 'Sales / Checkout';
$message = '';
$message_type = '';
$transaction_complete = false;
$transaction_data = null;

// Show a completed receipt using PRG (Post/Redirect/Get) so browser refresh
// cannot submit the same checkout form twice.
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['receipt'])) {
    $receipt_id = filter_var($_GET['receipt'], FILTER_VALIDATE_INT);
    if ($receipt_id) {
        $stmt = $pdo->prepare(
            "SELECT t.*, u.full_name AS cashier_name
             FROM transactions t
             LEFT JOIN users u ON u.id = t.user_id
             WHERE t.id = ? AND t.status = 'completed'"
        );
        $stmt->execute([$receipt_id]);
        $txn = $stmt->fetch();
        if ($txn) {
            $itemStmt = $pdo->prepare(
                "SELECT ti.quantity, ti.unit_price AS price, ti.subtotal, p.name
                 FROM transaction_items ti
                 JOIN products p ON p.id = ti.product_id
                 WHERE ti.transaction_id = ? ORDER BY ti.id"
            );
            $itemStmt->execute([$receipt_id]);
            $transaction_data = [
                'transaction_no' => $txn['transaction_no'],
                'cashier' => $txn['cashier_name'] ?? 'Unknown',
                'items' => $itemStmt->fetchAll(),
                'total' => (float)$txn['total_amount'],
                'discount' => (float)$txn['discount'],
                'grand_total' => (float)$txn['grand_total'],
                'payment_method' => $txn['payment_method'],
                'amount_paid' => (float)$txn['amount_paid'],
                'change' => (float)$txn['change_amount'],
                'date' => date('F j, Y - h:i A', strtotime($txn['created_at']))
            ];
            $transaction_complete = true;
        }
    }
}

// Handle transaction submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['complete_transaction'])) {
    verify_csrf();

    try {
        $pdo->beginTransaction();

        $raw_cart = json_decode($_POST['cart_data'] ?? '[]', true);
        if (!is_array($raw_cart) || empty($raw_cart)) {
            throw new RuntimeException('Cart is empty or invalid.');
        }

        // Only accept product IDs and quantities from the browser.
        // Names and prices are always reloaded from the database.
        $cart_quantities = [];
        foreach ($raw_cart as $item) {
            $product_id = filter_var($item['product_id'] ?? null, FILTER_VALIDATE_INT);
            $quantity = filter_var($item['quantity'] ?? null, FILTER_VALIDATE_INT);
            if ($product_id === false || $product_id <= 0 || $quantity === false || $quantity <= 0) {
                throw new RuntimeException('Invalid product or quantity in cart.');
            }
            $cart_quantities[$product_id] = ($cart_quantities[$product_id] ?? 0) + $quantity;
        }

        $discount = (float)($_POST['discount'] ?? 0);
        if (!is_finite($discount) || $discount < 0) {
            throw new RuntimeException('Invalid discount amount.');
        }

        $payment_method = $_POST['payment_method'] ?? 'cash';
        if (!in_array($payment_method, ['cash', 'card', 'ewallet'], true)) {
            throw new RuntimeException('Invalid payment method.');
        }

        $amount_paid = (float)($_POST['amount_paid'] ?? 0);
        if (!is_finite($amount_paid) || $amount_paid < 0) {
            throw new RuntimeException('Invalid payment amount.');
        }

        $product_ids = array_keys($cart_quantities);
        $placeholders = implode(',', array_fill(0, count($product_ids), '?'));
        $stmt = $pdo->prepare("SELECT id, name, price, cost_price, stock FROM products WHERE id IN ($placeholders) FOR UPDATE");
        $stmt->execute($product_ids);
        $products_by_id = [];
        while ($product = $stmt->fetch()) {
            $products_by_id[(int)$product['id']] = $product;
        }

        if (count($products_by_id) !== count($product_ids)) {
            throw new RuntimeException('One or more products no longer exist. Please refresh the cart.');
        }

        $total = 0.0;
        $receipt_items = [];
        foreach ($cart_quantities as $product_id => $quantity) {
            $product = $products_by_id[$product_id];
            $stock = (int)$product['stock'];
            if ($stock < $quantity) {
                throw new RuntimeException('Not enough stock for ' . $product['name'] . '. Available: ' . $stock . '.');
            }

            $unit_price = (float)$product['price'];
            $subtotal = $unit_price * $quantity;
            $total += $subtotal;
            $receipt_items[] = [
                'product_id' => $product_id,
                'name' => $product['name'],
                'price' => $unit_price,
                'cost_price' => (float)$product['cost_price'],
                'quantity' => $quantity,
                'subtotal' => $subtotal
            ];
        }

        if ($discount > $total) {
            $discount = $total;
        }
        $grand_total = round($total - $discount, 2);

        // Non-cash payments represent an exact electronic payment.
        if ($payment_method !== 'cash') {
            $amount_paid = $grand_total;
        } elseif ($amount_paid + 0.00001 < $grand_total) {
            throw new RuntimeException('Insufficient payment. Amount due: ₱' . number_format($grand_total, 2));
        }

        $change = round($amount_paid - $grand_total, 2);

        $transaction_no = 'TXN-' . date('YmdHis') . '-' . strtoupper(bin2hex(random_bytes(3)));

        $stmt = $pdo->prepare("INSERT INTO transactions (transaction_no, user_id, total_amount, discount, grand_total, payment_method, amount_paid, change_amount, status) VALUES (:no, :uid, :total, :discount, :grand, :method, :paid, :change, 'completed')");
        $stmt->execute([
            ':no' => $transaction_no,
            ':uid' => $_SESSION['user_id'],
            ':total' => $total,
            ':discount' => $discount,
            ':grand' => $grand_total,
            ':method' => $payment_method,
            ':paid' => $amount_paid,
            ':change' => $change
        ]);
        $transaction_id = $pdo->lastInsertId();

        $item_stmt = $pdo->prepare("INSERT INTO transaction_items (transaction_id, product_id, quantity, unit_price, cost_price, subtotal) VALUES (:tid, :pid, :qty, :price, :cost, :sub)");
        $stock_stmt = $pdo->prepare("UPDATE products SET stock = stock - :decrement WHERE id = :pid AND stock >= :required");

        foreach ($receipt_items as $item) {
            $item_stmt->execute([
                ':tid' => $transaction_id,
                ':pid' => $item['product_id'],
                ':qty' => $item['quantity'],
                ':price' => $item['price'],
                ':cost' => $item['cost_price'],
                ':sub' => $item['subtotal']
            ]);

            $stock_stmt->execute([
                ':decrement' => $item['quantity'],
                ':pid' => $item['product_id'],
                ':required' => $item['quantity']
            ]);
            if ($stock_stmt->rowCount() !== 1) {
                throw new RuntimeException('Stock changed during checkout. Please try the transaction again.');
            }
            record_stock_movement($pdo, (int)$item['product_id'], -(int)$item['quantity'], 'sale', $transaction_no, get_current_user_id(), 'Main Store', 'POS sale');
        }

        $pdo->commit();

        $transaction_data = [
            'transaction_no' => $transaction_no,
            'cashier' => $_SESSION['user_name'],
            'items' => $receipt_items,
            'total' => $total,
            'discount' => $discount,
            'grand_total' => $grand_total,
            'payment_method' => $payment_method,
            'amount_paid' => $amount_paid,
            'change' => $change,
            'date' => date('F j, Y - h:i A')
        ];
        // PRG prevents accidental duplicate sales when the user refreshes.
        header('Location: ' . BASE_URL . '/modules/checkout.php?receipt=' . (int)$transaction_id);
        exit;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $message = 'Transaction failed: ' . $e->getMessage();
        $message_type = 'error';
    }
}

require_once __DIR__ . '/../includes/header.php';
?>

<?php if ($message): ?>
<div class="alert alert-<?php echo $message_type; ?>">
    <i class="fas fa-exclamation-circle"></i>
    <?php echo htmlspecialchars($message); ?>
</div>
<?php endif; ?>

<?php if ($transaction_complete): ?>
<!-- Receipt Display -->
<div class="receipt-container" id="receipt">
    <div class="receipt">
        <div class="receipt-header">
            <h2><?php echo SITE_NAME; ?></h2>
            <p><?php echo htmlspecialchars($transaction_data['date']); ?></p>
        </div>
        <div class="receipt-info">
            <p><strong>Transaction #:</strong> <?php echo htmlspecialchars($transaction_data['transaction_no']); ?></p>
            <p><strong>Cashier:</strong> <?php echo htmlspecialchars($transaction_data['cashier']); ?></p>
        </div>
        <table class="receipt-table">
            <thead>
                <tr>
                    <th>Item</th>
                    <th>Qty</th>
                    <th>Price</th>
                    <th>Subtotal</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($transaction_data['items'] as $item): ?>
                <tr>
                    <td><?php echo htmlspecialchars($item['name']); ?></td>
                    <td><?php echo $item['quantity']; ?></td>
                    <td>₱<?php echo number_format($item['price'], 2); ?></td>
                    <td>₱<?php echo number_format($item['price'] * $item['quantity'], 2); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <div class="receipt-totals">
            <div class="receipt-row">
                <span>Subtotal:</span>
                <span>₱<?php echo number_format($transaction_data['total'], 2); ?></span>
            </div>
            <?php if ($transaction_data['discount'] > 0): ?>
            <div class="receipt-row">
                <span>Discount:</span>
                <span>-₱<?php echo number_format($transaction_data['discount'], 2); ?></span>
            </div>
            <?php endif; ?>
            <div class="receipt-row total">
                <span>Grand Total:</span>
                <span>₱<?php echo number_format($transaction_data['grand_total'], 2); ?></span>
            </div>
            <div class="receipt-row">
                <span>Payment (<?php echo ucfirst($transaction_data['payment_method']); ?>):</span>
                <span>₱<?php echo number_format($transaction_data['amount_paid'], 2); ?></span>
            </div>
            <div class="receipt-row">
                <span>Change:</span>
                <span>₱<?php echo number_format($transaction_data['change'], 2); ?></span>
            </div>
        </div>
        <div class="receipt-footer">
            <p>Thank you for your purchase!</p>
            <p>Please come again.</p>
        </div>
    </div>
    <div class="receipt-actions no-print">
        <button onclick="window.print()" class="btn btn-primary"><i class="fas fa-print"></i> Print Receipt</button>
        <a href="checkout.php" class="btn btn-success"><i class="fas fa-plus"></i> New Transaction</a>
        <a href="<?php echo BASE_URL; ?>/dashboard.php" class="btn btn-outline"><i class="fas fa-home"></i> Dashboard</a>
    </div>
</div>

<?php else: ?>
<!-- Checkout Interface -->
<div class="checkout-layout">
    <!-- Left Panel: Product Selection -->
    <div class="checkout-products">
        <div class="card">
            <div class="card-header checkout-products-header">
                <h3><i class="fas fa-basket-shopping"></i> Products</h3>
                <span class="checkout-header-note">Fresh picks for your basket</span>
            </div>
            <div class="card-body">
                <div class="search-bar">
                    <input type="text" id="productSearch" class="form-control" placeholder="Search by name or barcode..." onkeyup="searchProducts()">
                </div>
                <div class="filter-bar">
                    <select id="categoryFilter" onchange="filterProducts()">
                        <option value="">All Categories</option>
                        <?php
                        $stmt = $pdo->query("SELECT * FROM categories ORDER BY name");
                        while ($cat = $stmt->fetch()) {
                            echo '<option value="' . $cat['id'] . '">' . htmlspecialchars($cat['name']) . '</option>';
                        }
                        ?>
                    </select>
                </div>
                <div class="product-grid" id="productGrid">
                    <?php
                    $stmt = $pdo->query("SELECT p.*, c.name as category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id WHERE p.stock > 0 ORDER BY p.name");
                    $products = $stmt->fetchAll();
                    foreach ($products as $product):
                    $product_image = product_image_url($product);
                    ?>
                    <div class="product-card" data-id="<?php echo $product['id']; ?>" data-name="<?php echo htmlspecialchars(strtolower($product['name'])); ?>" data-barcode="<?php echo htmlspecialchars(strtolower($product['barcode'] ?? '')); ?>" data-category="<?php echo $product['category_id']; ?>">
                        <div class="product-image-wrap">
                            <img src="<?php echo htmlspecialchars($product_image); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" loading="lazy">
                        </div>
                        <div class="product-card-info">
                            <h4><?php echo htmlspecialchars($product['name']); ?></h4>
                            <span class="product-category"><?php echo htmlspecialchars($product['category_name'] ?? 'Uncategorized'); ?></span>
                            <div class="product-card-bottom">
                                <span class="product-price">₱<?php echo number_format($product['price'], 2); ?></span>
                                <span class="product-stock">Stock: <?php echo $product['stock']; ?></span>
                            </div>
                        </div>
                        <button class="btn btn-sm btn-success add-to-cart-btn" onclick="addToCart(<?php echo (int)$product['id']; ?>, this.dataset.name, <?php echo (float)$product['price']; ?>, <?php echo (int)$product['stock']; ?>)" data-name="<?php echo htmlspecialchars($product['name'], ENT_QUOTES, 'UTF-8'); ?>">
                            <i class="fas fa-plus"></i> Add
                        </button>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Right Panel: Cart -->
    <div class="checkout-cart">
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-shopping-cart"></i> Cart</h3>
                <button class="btn btn-sm btn-danger" onclick="clearCart()">
                    <i class="fas fa-trash"></i> Clear
                </button>
            </div>
            <div class="card-body cart-body">
                <div id="cartItems" class="cart-items">
                    <p class="text-muted text-center empty-cart-msg">
                        <i class="fas fa-shopping-basket"></i><br>
                        Click products to add them to the cart
                    </p>
                </div>
            </div>
            <div class="card-footer cart-footer">
                <div class="cart-summary">
                    <div class="summary-row">
                        <span>Items:</span>
                        <span id="itemCount">0</span>
                    </div>
                    <div class="summary-row">
                        <span>Subtotal:</span>
                        <span id="cartSubtotal">₱0.00</span>
                    </div>
                    <div class="summary-row discount-row">
                        <span>Discount:</span>
                        <div class="discount-input">
                            <input type="number" id="discount" name="discount" value="0" min="0" step="0.01" onchange="updateCartTotals()">
                        </div>
                    </div>
                    <div class="summary-row total-row">
                        <span><strong>Grand Total:</strong></span>
                        <span id="cartGrandTotal"><strong>₱0.00</strong></span>
                    </div>
                </div>
                <button class="btn btn-success btn-block btn-lg" onclick="openPaymentModal()">
                    <i class="fas fa-credit-card"></i> Proceed to Payment
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Payment Modal -->
<div id="paymentModal" class="modal">
    <div class="modal-content modal-lg">
        <div class="modal-header">
            <h3><i class="fas fa-money-bill-wave"></i> Payment</h3>
            <button class="close-modal" onclick="closeModal('paymentModal')">&times;</button>
        </div>
        <div class="modal-body">
            <form method="POST" id="paymentForm">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrf_token()); ?>">
                <input type="hidden" name="cart_data" id="cartDataInput">
                <input type="hidden" name="discount" id="discountInput">
                <input type="hidden" name="complete_transaction" value="1">

                <div class="payment-summary">
                    <div class="summary-row total-row">
                        <span>Amount Due:</span>
                        <span id="paymentTotal">₱0.00</span>
                    </div>
                </div>

                <div class="form-group">
                    <label>Payment Method</label>
                    <div class="payment-methods">
                        <label class="payment-method">
                            <input type="radio" name="payment_method" value="cash" checked onchange="togglePaymentFields()">
                            <i class="fas fa-money-bill-wave"></i> Cash
                        </label>
                        <label class="payment-method">
                            <input type="radio" name="payment_method" value="card" onchange="togglePaymentFields()">
                            <i class="fas fa-credit-card"></i> Card
                        </label>
                        <label class="payment-method">
                            <input type="radio" name="payment_method" value="ewallet" onchange="togglePaymentFields()">
                            <i class="fas fa-mobile-alt"></i> E-Wallet
                        </label>
                    </div>
                </div>

                <div id="cashFields">
                    <div class="form-group">
                        <label for="amount_paid">Amount Paid</label>
                        <input type="number" id="amount_paid" name="amount_paid" step="0.01" min="0" required oninput="calculateChange()">
                    </div>
                    <div class="form-group">
                        <label>Change</label>
                        <div class="change-display" id="changeDisplay">₱0.00</div>
                    </div>
                </div>

                <button type="submit" class="btn btn-success btn-block btn-lg">
                    <i class="fas fa-check"></i> Complete Transaction
                </button>
            </form>
        </div>
    </div>
</div>

<script>
// Cart State
let cart = [];

function addToCart(id, name, price, stock) {
    const existing = cart.find(item => item.product_id === id);
    if (existing) {
        if (existing.quantity >= stock) {
            alert('Not enough stock available!');
            return;
        }
        existing.quantity++;
    } else {
        cart.push({ product_id: id, name: name, price: price, quantity: 1, max_stock: stock });
    }
    renderCart();
}

function removeFromCart(index) {
    cart.splice(index, 1);
    renderCart();
}

function updateQuantity(index, qty) {
    const item = cart[index];
    if (qty <= 0) {
        removeFromCart(index);
        return;
    }
    if (qty > item.max_stock) {
        alert('Not enough stock! Maximum available: ' + item.max_stock);
        qty = item.max_stock;
    }
    cart[index].quantity = qty;
    renderCart();
}

function clearCart() {
    if (cart.length > 0 && confirm('Clear all items from cart?')) {
        cart = [];
        renderCart();
    }
}

function renderCart() {
    const container = document.getElementById('cartItems');
    if (cart.length === 0) {
        container.innerHTML = '<p class="text-muted text-center empty-cart-msg"><i class="fas fa-shopping-basket"></i><br>Click products to add them to the cart</p>';
        document.getElementById('itemCount').textContent = '0';
        document.getElementById('cartSubtotal').textContent = '₱0.00';
        document.getElementById('cartGrandTotal').innerHTML = '<strong>₱0.00</strong>';
        return;
    }

    let html = '';
    let subtotal = 0;
    let totalItems = 0;

    cart.forEach((item, index) => {
        const itemTotal = item.price * item.quantity;
        subtotal += itemTotal;
        totalItems += item.quantity;

        html += `
        <div class="cart-item">
            <div class="cart-item-info">
                <strong>${escapeHtml(item.name)}</strong>
                <span>₱${item.price.toFixed(2)} each</span>
            </div>
            <div class="cart-item-controls">
                <button onclick="updateQuantity(${index}, ${item.quantity - 1})" class="qty-btn">-</button>
                <input type="number" value="${item.quantity}" min="1" max="${item.max_stock}" onchange="updateQuantity(${index}, parseInt(this.value))" class="qty-input">
                <button onclick="updateQuantity(${index}, ${item.quantity + 1})" class="qty-btn">+</button>
            </div>
            <div class="cart-item-total">₱${itemTotal.toFixed(2)}</div>
            <button onclick="removeFromCart(${index})" class="cart-item-remove"><i class="fas fa-times"></i></button>
        </div>`;
    });

    container.innerHTML = html;
    document.getElementById('itemCount').textContent = totalItems;
    document.getElementById('cartSubtotal').textContent = '₱' + subtotal.toFixed(2);
    updateCartTotals();
}

function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, character => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    })[character]);
}

function updateCartTotals() {
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const discount = parseFloat(document.getElementById('discount').value) || 0;
    const grandTotal = Math.max(subtotal - discount, 0);
    document.getElementById('cartGrandTotal').innerHTML = '<strong>₱' + grandTotal.toFixed(2) + '</strong>';
}

function openPaymentModal() {
    if (cart.length === 0) {
        alert('Cart is empty! Please add items first.');
        return;
    }
    const discount = parseFloat(document.getElementById('discount').value) || 0;
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const grandTotal = Math.max(subtotal - discount, 0);
    document.getElementById('paymentTotal').textContent = '₱' + grandTotal.toFixed(2);
    document.getElementById('amount_paid').value = grandTotal.toFixed(2);
    document.getElementById('amount_paid').setAttribute('data-grand', grandTotal);
    calculateChange();
    document.getElementById('paymentModal').classList.add('active');
}

function closeModal(id) {
    document.getElementById(id).classList.remove('active');
}

function togglePaymentFields() {
    const method = document.querySelector('input[name="payment_method"]:checked').value;
    document.getElementById('cashFields').style.display = method === 'cash' ? 'block' : 'none';
}

function calculateChange() {
    const paid = parseFloat(document.getElementById('amount_paid').value) || 0;
    const grandTotal = parseFloat(document.getElementById('amount_paid').getAttribute('data-grand')) || 0;
    const change = paid - grandTotal;
    const display = document.getElementById('changeDisplay');
    if (change >= 0) {
        display.textContent = '₱' + change.toFixed(2);
        display.className = 'change-display change-positive';
    } else {
        display.textContent = '-₱' + Math.abs(change).toFixed(2);
        display.className = 'change-display change-negative';
    }
}

// Payment form submit
document.getElementById('paymentForm').addEventListener('submit', function(e) {
    const discount = parseFloat(document.getElementById('discount').value) || 0;
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const grandTotal = Math.max(subtotal - discount, 0);
    const method = document.querySelector('input[name="payment_method"]:checked').value;
    const paid = method === 'cash' ? parseFloat(document.getElementById('amount_paid').value) || 0 : grandTotal;

    if (method === 'cash' && paid < grandTotal) {
        e.preventDefault();
        alert('Insufficient payment! Please enter a sufficient amount.');
        return;
    }

    // Set hidden values
    document.getElementById('cartDataInput').value = JSON.stringify(cart);
    document.getElementById('discountInput').value = discount;
});

// Search
function searchProducts() {
    const query = document.getElementById('productSearch').value.toLowerCase();
    const cards = document.querySelectorAll('.product-card');
    cards.forEach(card => {
        const name = card.dataset.name;
        const barcode = card.dataset.barcode;
        if (name.includes(query) || barcode.includes(query)) {
            card.style.display = '';
        } else {
            card.style.display = 'none';
        }
    });
}

function filterProducts() {
    const catId = document.getElementById('categoryFilter').value;
    const cards = document.querySelectorAll('.product-card');
    cards.forEach(card => {
        if (!catId || card.dataset.category === catId) {
            card.style.display = '';
        } else {
            card.style.display = 'none';
        }
    });
}
</script>

<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
