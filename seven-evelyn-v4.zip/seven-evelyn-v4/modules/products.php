<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/pagination.php';

$allowed_roles = ['admin', 'owner', 'manager', 'inventory'];
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['user_role'], $allowed_roles, true)) {
    header('Location: ' . BASE_URL . '/dashboard.php');
    exit;
}

$pageTitle = 'Product Management';
$message = '';
$message_type = '';
$action = $_GET['action'] ?? 'list';

function handle_product_image_upload(): ?string {
    if (!isset($_FILES['image']) || $_FILES['image']['error'] === UPLOAD_ERR_NO_FILE) {
        return null;
    }
    if ($_FILES['image']['error'] !== UPLOAD_ERR_OK || $_FILES['image']['size'] > 5 * 1024 * 1024) {
        throw new RuntimeException('Image upload failed or is larger than 5 MB.');
    }

    $image_info = getimagesize($_FILES['image']['tmp_name']);
    $allowed_types = [IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_WEBP, IMAGETYPE_GIF];
    if ($image_info === false || !in_array($image_info[2], $allowed_types, true)) {
        throw new RuntimeException('Please upload a valid JPG, PNG, WEBP, or GIF image.');
    }

    $extension = image_type_to_extension($image_info[2], false);
    $filename = bin2hex(random_bytes(16)) . '.' . $extension;
    $upload_dir = __DIR__ . '/../uploads';
    if (!is_dir($upload_dir) && !mkdir($upload_dir, 0755, true)) {
        throw new RuntimeException('Product image folder is not available.');
    }
    if (!move_uploaded_file($_FILES['image']['tmp_name'], $upload_dir . '/' . $filename)) {
        throw new RuntimeException('Unable to save the product image.');
    }
    return $filename;
}

// Handle Add/Edit Product
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product_action'])) {
    verify_csrf();
    $barcode = trim($_POST['barcode'] ?? '');
    $name = trim($_POST['name'] ?? '');
    $category_id = (int)($_POST['category_id'] ?? 0);
    $price = (float)($_POST['price'] ?? 0);
    $cost_price = (float)($_POST['cost_price'] ?? 0);
    $stock = (int)($_POST['stock'] ?? 0);
    $low_stock_threshold = (int)($_POST['low_stock_threshold'] ?? 10);
    $description = trim($_POST['description'] ?? '');

    if (empty($name)) {
        $message = 'Product name is required.';
        $message_type = 'error';
    } elseif ($price < 0 || $cost_price < 0 || $stock < 0 || $low_stock_threshold < 0) {
        $message = 'Price, cost, stock, and low-stock threshold cannot be negative.';
        $message_type = 'error';
    } else {
        try {
            $uploaded_image = handle_product_image_upload();
            if ($_POST['product_action'] === 'add') {
                $stmt = $pdo->prepare("INSERT INTO products (barcode, name, category_id, price, cost_price, stock, low_stock_threshold, image, description) VALUES (:barcode, :name, :category_id, :price, :cost_price, :stock, :threshold, :image, :description)");
                $stmt->execute([
                    ':barcode' => $barcode ?: null,
                    ':name' => $name,
                    ':category_id' => $category_id ?: null,
                    ':price' => $price,
                    ':cost_price' => $cost_price,
                    ':stock' => $stock,
                    ':threshold' => $low_stock_threshold,
                    ':image' => $uploaded_image,
                    ':description' => $description
                ]);
                $message = 'Product added successfully!';
                $message_type = 'success';
            } elseif ($_POST['product_action'] === 'edit') {
                $product_id = (int)($_POST['product_id'] ?? 0);
                if ($product_id <= 0) {
                    throw new RuntimeException('Invalid product selected.');
                }

                $pdo->beginTransaction();
                $check = $pdo->prepare('SELECT stock FROM products WHERE id = ? FOR UPDATE');
                $check->execute([$product_id]);
                $old_stock = $check->fetchColumn();
                if ($old_stock === false) {
                    throw new RuntimeException('Product not found.');
                }

                $image_sql = $uploaded_image !== null ? ', image = :image' : '';
                $stmt = $pdo->prepare("UPDATE products SET barcode = :barcode, name = :name, category_id = :category_id, price = :price, cost_price = :cost_price, stock = :stock, low_stock_threshold = :threshold$image_sql, description = :description WHERE id = :id");
                $stmt->execute([
                    ':barcode' => $barcode ?: null,
                    ':name' => $name,
                    ':category_id' => $category_id ?: null,
                    ':price' => $price,
                    ':cost_price' => $cost_price,
                    ':stock' => $stock,
                    ':threshold' => $low_stock_threshold,
                    ...($uploaded_image !== null ? [':image' => $uploaded_image] : []),
                    ':description' => $description,
                    ':id' => $product_id
                ]);
                $delta = $stock - (int)$old_stock;
                record_stock_movement($pdo, $product_id, $delta, 'manual_adjustment', null, get_current_user_id(), 'Main Store', 'Product edit stock adjustment');
                $pdo->commit();
                $message = 'Product updated successfully!';
                $message_type = 'success';
            }
            $action = 'list';
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $message = $e instanceof RuntimeException ? $e->getMessage() : 'Database error while saving the product.';
            $message_type = 'error';
        }
    }
}

// Handle destructive actions through POST + CSRF only.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['delete_product'])) {
        verify_csrf();
        $delete_id = (int)($_POST['product_id'] ?? 0);
        try {
            $check = $pdo->prepare('SELECT COUNT(*) FROM transaction_items WHERE product_id = ?');
            $check->execute([$delete_id]);
            if ((int)$check->fetchColumn() > 0) {
                throw new RuntimeException('This product has sales history and cannot be deleted. Edit it or set its stock to 0 instead.');
            }
            $stmt = $pdo->prepare('DELETE FROM products WHERE id = :id');
            $stmt->execute([':id' => $delete_id]);
            $deleted = $stmt->rowCount();
            $message = $deleted ? 'Product deleted successfully!' : 'Product not found.';
            $message_type = $deleted ? 'success' : 'error';
        } catch (Throwable $e) {
            $message = $e instanceof RuntimeException ? $e->getMessage() : 'Error deleting product.';
            $message_type = 'error';
        }
        $action = 'list';
    }

    if (isset($_POST['category_action'])) {
        verify_csrf();
        $cat_name = trim($_POST['cat_name'] ?? '');
        if (!empty($cat_name)) {
            try {
                $stmt = $pdo->prepare('INSERT INTO categories (name) VALUES (:name)');
                $stmt->execute([':name' => $cat_name]);
                $message = 'Category added successfully!';
                $message_type = 'success';
            } catch (PDOException $e) {
                $message = 'Error adding category. It may already exist.';
                $message_type = 'error';
            }
        }
        if (isset($_POST['delete_category'])) {
            $cat_id = (int)($_POST['category_id'] ?? 0);
            try {
                $stmt = $pdo->prepare('DELETE FROM categories WHERE id = :id');
                $stmt->execute([':id' => $cat_id]);
                $message = $stmt->rowCount() ? 'Category deleted!' : 'Category not found.';
                $message_type = $stmt->rowCount() ? 'success' : 'error';
            } catch (PDOException $e) {
                $message = 'Error deleting category.';
                $message_type = 'error';
            }
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
?>

<?php if ($message): ?>
<div class="alert alert-<?php echo $message_type; ?> alert-dismissible">
    <i class="fas fa-<?php echo $message_type === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
    <?php echo htmlspecialchars($message); ?>
    <button class="close-btn" onclick="this.parentElement.remove()">&times;</button>
</div>
<?php endif; ?>

<?php if ($action === 'list'): ?>
<!-- Product List View -->
<?php
$per_page = get_per_page();
$page = get_current_page();
$search = get_search_query();

$sort_columns = [
    'barcode'    => 'p.barcode',
    'name'       => 'p.name',
    'category'   => 'c.name',
    'price'      => 'p.price',
    'cost_price' => 'p.cost_price',
    'stock'      => 'p.stock',
];
$sort = get_sort_column($sort_columns, 'name');
$dir = get_sort_direction();

$where_sql = '';
$where_params = [];
if ($search !== '') {
    // Native (non-emulated) prepares can't reuse the same named
    // placeholder more than once per query, so each LIKE gets its own.
    $where_sql = 'WHERE (p.name LIKE :q1 OR p.barcode LIKE :q2 OR c.name LIKE :q3)';
    $like = '%' . $search . '%';
    $where_params = [':q1' => $like, ':q2' => $like, ':q3' => $like];
}

$count_stmt = $pdo->prepare("SELECT COUNT(*) FROM products p LEFT JOIN categories c ON p.category_id = c.id $where_sql");
$count_stmt->execute($where_params);
$total_products = (int)$count_stmt->fetchColumn();
?>
<div class="card">
    <div class="card-header">
        <h3><i class="fas fa-box"></i> All Products</h3>
        <div class="header-actions">
            <?php render_search_box($search, 'Search products...'); ?>
            <?php render_per_page_selector($per_page); ?>
            <a href="?action=add" class="btn btn-primary"><i class="fas fa-plus"></i> Add Product</a>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Image</th>
                        <th><?php render_sort_link('Barcode', 'barcode', $sort, $dir); ?></th>
                        <th><?php render_sort_link('Name', 'name', $sort, $dir); ?></th>
                        <th><?php render_sort_link('Category', 'category', $sort, $dir); ?></th>
                        <th><?php render_sort_link('Price', 'price', $sort, $dir); ?></th>
                        <th><?php render_sort_link('Cost', 'cost_price', $sort, $dir); ?></th>
                        <th><?php render_sort_link('Stock', 'stock', $sort, $dir); ?></th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $stmt = $pdo->prepare("SELECT p.*, c.name as category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id $where_sql ORDER BY {$sort_columns[$sort]} $dir LIMIT :limit OFFSET :offset");
                    foreach ($where_params as $key => $value) {
                        $stmt->bindValue($key, $value);
                    }
                    $stmt->bindValue(':limit', $per_page, PDO::PARAM_INT);
                    $stmt->bindValue(':offset', get_pagination_offset($page, $per_page), PDO::PARAM_INT);
                    $stmt->execute();
                    $products = $stmt->fetchAll();
                    ?>
                    <?php if (empty($products)): ?>
                    <tr>
                        <td colspan="8" class="text-center text-muted" style="padding: 40px;">
                            No products found<?php echo $search !== '' ? ' for "' . htmlspecialchars($search) . '"' : ''; ?>.
                        </td>
                    </tr>
                    <?php else: ?>
                    <?php foreach ($products as $product):
                        $stock_class = $product['stock'] <= $product['low_stock_threshold'] ? 'stock-low' : 'stock-ok';
                        $product_image_url = product_image_url($product);
                    ?>
                    <tr>
                        <td>
                            <img src="<?php echo htmlspecialchars($product_image_url); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" class="product-thumb" loading="lazy">
                        </td>
                        <td><?php echo htmlspecialchars($product['barcode'] ?? '-'); ?></td>
                        <td><strong><?php echo htmlspecialchars($product['name']); ?></strong></td>
                        <td><?php echo htmlspecialchars($product['category_name'] ?? 'Uncategorized'); ?></td>
                        <td>₱<?php echo number_format($product['price'], 2); ?></td>
                        <td>₱<?php echo number_format($product['cost_price'], 2); ?></td>
                        <td><span class="<?php echo $stock_class; ?>"><?php echo $product['stock']; ?></span></td>
                        <td>
                            <a href="?action=edit&id=<?php echo $product['id']; ?>" class="btn btn-sm btn-warning" title="Edit">
                                <i class="fas fa-edit"></i>
                            </a>
                            <form method="POST" style="display:inline" onsubmit="return confirm('Are you sure you want to delete this product?')">
                                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrf_token()); ?>">
                                <input type="hidden" name="product_id" value="<?php echo (int)$product['id']; ?>">
                                <button type="submit" name="delete_product" class="btn btn-sm btn-danger" title="Delete"><i class="fas fa-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php render_pagination($page, $total_products, $per_page); ?>
    </div>
</div>

<!-- Categories Section -->
<div class="card mt-3">
    <div class="card-header">
        <h3><i class="fas fa-tags"></i> Product Categories</h3>
    </div>
    <div class="card-body">
        <div class="category-grid">
            <?php
            $stmt = $pdo->query("SELECT * FROM categories ORDER BY name ASC");
            $categories = $stmt->fetchAll();
            foreach ($categories as $cat):
            ?>
            <div class="category-item">
                <span><?php echo htmlspecialchars($cat['name']); ?></span>
                <form method="POST" style="display:inline" onsubmit="return confirm('Delete this category?')">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrf_token()); ?>">
                    <input type="hidden" name="category_id" value="<?php echo (int)$cat['id']; ?>">
                    <input type="hidden" name="category_action" value="delete">
                    <button type="submit" name="delete_category" class="btn btn-sm btn-danger"><i class="fas fa-times"></i></button>
                </form>
            </div>
            <?php endforeach; ?>
        </div>
        <form method="POST" class="inline-form mt-2">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrf_token()); ?>">
            <input type="hidden" name="category_action" value="add">
            <div class="input-group">
                <input type="text" name="cat_name" placeholder="New category name" required>
                <button type="submit" class="btn btn-primary"><i class="fas fa-plus"></i> Add</button>
            </div>
        </form>
    </div>
</div>

<?php elseif ($action === 'add' || $action === 'edit'): ?>
<!-- Add/Edit Product Form -->
<div class="card">
    <div class="card-header">
        <h3>
            <?php
            $product = null;
            if ($action === 'edit' && isset($_GET['id'])) {
                $stmt = $pdo->prepare("SELECT * FROM products WHERE id = :id");
                $stmt->execute([':id' => (int)$_GET['id']]);
                $product = $stmt->fetch();
            }
            echo $product ? '<i class="fas fa-edit"></i> Edit Product' : '<i class="fas fa-plus"></i> Add New Product';
            ?>
        </h3>
        <a href="?action=list" class="btn btn-outline"><i class="fas fa-arrow-left"></i> Back to List</a>
    </div>
    <div class="card-body">
            <form method="POST" enctype="multipart/form-data" class="form-horizontal">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrf_token()); ?>">
            <input type="hidden" name="product_action" value="<?php echo $product ? 'edit' : 'add'; ?>">
            <?php if ($product): ?>
            <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
            <?php endif; ?>

            <div class="form-row">
                <div class="form-group">
                    <label for="image">Product Image</label>
                    <input type="file" id="image" name="image" accept="image/jpeg,image/png,image/webp,image/gif">
                    <small class="form-text">JPG, PNG, WEBP, or GIF. Maximum 5 MB.</small>
                    <?php if ($product && !empty($product['image'])): ?>
                    <img src="<?php echo BASE_URL; ?>/uploads/<?php echo rawurlencode(basename($product['image'])); ?>" alt="Current product image" class="product-preview">
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="barcode">Barcode / Code</label>
                    <input type="text" id="barcode" name="barcode" value="<?php echo htmlspecialchars($product['barcode'] ?? ''); ?>" placeholder="e.g., 4800001001">
                </div>
                <div class="form-group">
                    <label for="name">Product Name *</label>
                    <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($product['name'] ?? ''); ?>" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="category_id">Category</label>
                    <select id="category_id" name="category_id">
                        <option value="">-- Select Category --</option>
                        <?php
                        $stmt = $pdo->query("SELECT * FROM categories ORDER BY name");
                        $cats = $stmt->fetchAll();
                        foreach ($cats as $cat):
                        ?>
                        <option value="<?php echo $cat['id']; ?>" <?php echo ($product && $product['category_id'] == $cat['id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($cat['name']); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="description">Description</label>
                    <input type="text" id="description" name="description" value="<?php echo htmlspecialchars($product['description'] ?? ''); ?>">
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="price">Price *</label>
                    <input type="number" id="price" name="price" step="0.01" min="0" value="<?php echo $product['price'] ?? ''; ?>" required>
                </div>
                <div class="form-group">
                    <label for="cost_price">Cost Price *</label>
                    <input type="number" id="cost_price" name="cost_price" step="0.01" min="0" value="<?php echo $product['cost_price'] ?? ''; ?>" required>
                </div>
                <div class="form-group">
                    <label for="stock">Stock *</label>
                    <input type="number" id="stock" name="stock" min="0" value="<?php echo $product['stock'] ?? '0'; ?>" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="low_stock_threshold">Low Stock Threshold</label>
                    <input type="number" id="low_stock_threshold" name="low_stock_threshold" min="0" value="<?php echo $product['low_stock_threshold'] ?? '10'; ?>">
                </div>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> <?php echo $product ? 'Update Product' : 'Save Product'; ?>
                </button>
                <a href="?action=list" class="btn btn-outline">Cancel</a>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
