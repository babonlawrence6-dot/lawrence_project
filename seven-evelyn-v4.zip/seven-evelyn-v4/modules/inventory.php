<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/pagination.php';

// Allow roles with inventory access
$allowed_roles = ['admin', 'owner', 'manager', 'inventory', 'warehouse'];
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['user_role'], $allowed_roles, true)) {
    header('Location: ' . BASE_URL . '/dashboard.php');
    exit;
}

$pageTitle = 'Inventory Management';
$message = '';
$message_type = '';

// Handle stock update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['stock_action'])) {
    verify_csrf();
    $product_id = (int)($_POST['product_id'] ?? 0);
    $action_type = $_POST['stock_action'];

    if ($product_id > 0) {
        try {
            $pdo->beginTransaction();
            if ($action_type === 'update') {
                $new_stock = (int)($_POST['new_stock'] ?? -1);
                if ($new_stock < 0) throw new RuntimeException('Stock cannot be negative.');
                $check = $pdo->prepare('SELECT stock FROM products WHERE id = ? FOR UPDATE');
                $check->execute([$product_id]);
                $current_stock = $check->fetchColumn();
                if ($current_stock === false) throw new RuntimeException('Product not found.');
                $delta = $new_stock - (int)$current_stock;
                $stmt = $pdo->prepare('UPDATE products SET stock = ? WHERE id = ?');
                $stmt->execute([$new_stock, $product_id]);
                record_stock_movement($pdo, $product_id, $delta, 'manual_adjustment', null, get_current_user_id(), 'Main Store', 'Manual stock set');
                $message = 'Stock updated successfully!';
                $message_type = 'success';
            } elseif ($action_type === 'restock') {
                $add_quantity = (int)($_POST['add_quantity'] ?? 0);
                if ($add_quantity <= 0) throw new RuntimeException('Quantity must be greater than zero.');
                $check = $pdo->prepare('SELECT id FROM products WHERE id = ? FOR UPDATE');
                $check->execute([$product_id]);
                if (!$check->fetch()) throw new RuntimeException('Product not found.');
                $stmt = $pdo->prepare('UPDATE products SET stock = stock + ? WHERE id = ?');
                $stmt->execute([$add_quantity, $product_id]);
                record_stock_movement($pdo, $product_id, $add_quantity, 'restock', null, get_current_user_id(), 'Main Store', 'Manual restock');
                $message = "Added {$add_quantity} units to stock!";
                $message_type = 'success';
            } else {
                throw new RuntimeException('Invalid inventory action.');
            }
            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $message = 'Error updating stock: ' . $e->getMessage();
            $message_type = 'error';
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
?>

<?php if ($message): ?>
<div class="alert alert-<?php echo $message_type; ?> alert-dismissible">
    <i class="fas fa-<?php echo $message_type === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
    <?php echo htmlspecialchars($message); ?>
    <button class="close-btn" onclick="this.parentElement.remove()">&times;</button>
</div>
<?php endif; ?>

<!-- Inventory Summary -->
<div class="dashboard-grid mb-3">
    <?php
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM products");
    $total_products = $stmt->fetch()['total'];

    $stmt = $pdo->query("SELECT SUM(stock) as total FROM products");
    $total_stock = $stmt->fetch()['total'];

    $stmt = $pdo->query("SELECT COUNT(*) as total FROM products WHERE stock <= low_stock_threshold");
    $low_stock_count = $stmt->fetch()['total'];

    $stmt = $pdo->query("SELECT COUNT(*) as total FROM products WHERE stock = 0");
    $out_of_stock = $stmt->fetch()['total'];
    ?>

    <div class="stat-card">
        <div class="stat-icon bg-blue"><i class="fas fa-boxes"></i></div>
        <div class="stat-info">
            <h3><?php echo number_format($total_products); ?></h3>
            <p>Total Products</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon bg-green"><i class="fas fa-cubes"></i></div>
        <div class="stat-info">
            <h3><?php echo number_format($total_stock ?? 0); ?></h3>
            <p>Total Stock Units</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon bg-orange"><i class="fas fa-exclamation-triangle"></i></div>
        <div class="stat-info">
            <h3><?php echo number_format($low_stock_count); ?></h3>
            <p>Low Stock</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon bg-red"><i class="fas fa-times-circle"></i></div>
        <div class="stat-info">
            <h3><?php echo number_format($out_of_stock); ?></h3>
            <p>Out of Stock</p>
        </div>
    </div>
</div>

<!-- Inventory Table with Stock Controls -->
<?php
$per_page = get_per_page();
$page = get_current_page();
$search = get_search_query();

$sort_columns = [
    'barcode'   => 'p.barcode',
    'name'      => 'p.name',
    'category'  => 'c.name',
    'stock'     => 'p.stock',
    'threshold' => 'p.low_stock_threshold',
];
$sort = get_sort_column($sort_columns, 'name');
$dir = get_sort_direction();

$where_sql = '';
$where_params = [];
if ($search !== '') {
    // Native (non-emulated) prepares can't reuse the same named
    // placeholder more than once per query, so each LIKE gets its own.
    $where_sql = 'WHERE (p.name LIKE :q1 OR p.barcode LIKE :q2 OR c.name LIKE :q3)';
    $like = '%' . $search . '%';
    $where_params = [':q1' => $like, ':q2' => $like, ':q3' => $like];
}

$count_stmt = $pdo->prepare("SELECT COUNT(*) FROM products p LEFT JOIN categories c ON p.category_id = c.id $where_sql");
$count_stmt->execute($where_params);
$total_inventory = (int)$count_stmt->fetchColumn();
?>
<div class="card">
    <div class="card-header">
        <h3><i class="fas fa-warehouse"></i> Stock Overview</h3>
        <div class="header-actions">
            <?php render_search_box($search, 'Search inventory...'); ?>
            <?php render_per_page_selector($per_page); ?>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th><?php render_sort_link('Barcode', 'barcode', $sort, $dir); ?></th>
                        <th><?php render_sort_link('Product', 'name', $sort, $dir); ?></th>
                        <th><?php render_sort_link('Category', 'category', $sort, $dir); ?></th>
                        <th><?php render_sort_link('Current Stock', 'stock', $sort, $dir); ?></th>
                        <th><?php render_sort_link('Threshold', 'threshold', $sort, $dir); ?></th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $stmt = $pdo->prepare("SELECT p.*, c.name as category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id $where_sql ORDER BY {$sort_columns[$sort]} $dir LIMIT :limit OFFSET :offset");
                    foreach ($where_params as $key => $value) {
                        $stmt->bindValue($key, $value);
                    }
                    $stmt->bindValue(':limit', $per_page, PDO::PARAM_INT);
                    $stmt->bindValue(':offset', get_pagination_offset($page, $per_page), PDO::PARAM_INT);
                    $stmt->execute();
                    $inventory = $stmt->fetchAll();
                    ?>
                    <?php if (empty($inventory)): ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted" style="padding: 40px;">
                            No products found<?php echo $search !== '' ? ' for "' . htmlspecialchars($search) . '"' : ''; ?>.
                        </td>
                    </tr>
                    <?php else: ?>
                    <?php foreach ($inventory as $item):
                        $stock_class = 'stock-ok';
                        $stock_label = 'In Stock';
                        if ($item['stock'] == 0) {
                            $stock_class = 'stock-out';
                            $stock_label = 'Out of Stock';
                        } elseif ($item['stock'] <= $item['low_stock_threshold']) {
                            $stock_class = 'stock-low';
                            $stock_label = 'Low Stock';
                        }
                    ?>
                    <tr>
                        <td><?php echo htmlspecialchars($item['barcode'] ?? '-'); ?></td>
                        <td><strong><?php echo htmlspecialchars($item['name']); ?></strong></td>
                        <td><?php echo htmlspecialchars($item['category_name'] ?? 'Uncategorized'); ?></td>
                        <td><strong><?php echo $item['stock']; ?></strong></td>
                        <td><?php echo $item['low_stock_threshold']; ?></td>
                        <td><span class="badge badge-<?php echo $stock_class; ?>"><?php echo $stock_label; ?></span></td>
                        <td>
                            <button class="btn btn-sm btn-primary" onclick='openRestockModal(<?php echo $item['id']; ?>, <?php echo json_encode($item['name'], JSON_HEX_APOS | JSON_HEX_QUOT); ?>, <?php echo $item['stock']; ?>)' title="Restock">
                                <i class="fas fa-plus"></i>
                            </button>
                            <button class="btn btn-sm btn-warning" onclick='openUpdateModal(<?php echo $item['id']; ?>, <?php echo json_encode($item['name'], JSON_HEX_APOS | JSON_HEX_QUOT); ?>, <?php echo $item['stock']; ?>)' title="Set Stock">
                                <i class="fas fa-edit"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php render_pagination($page, $total_inventory, $per_page); ?>
    </div>
</div>

<!-- Inventory Movement History -->
<div class="card mt-3">
    <div class="card-header"><h3><i class="fas fa-history"></i> Recent Stock Movements</h3></div>
    <div class="card-body"><div class="table-responsive"><table class="table table-striped"><thead><tr><th>Date</th><th>Product</th><th>Type</th><th>Change</th><th>Location</th><th>Reference</th><th>User</th></tr></thead><tbody>
    <?php
    $movement_stmt = $pdo->query("SELECT sm.*, p.name product_name, COALESCE(u.full_name,'System') user_name FROM stock_movements sm JOIN products p ON sm.product_id=p.id LEFT JOIN users u ON sm.user_id=u.id ORDER BY sm.created_at DESC LIMIT 30");
    $movements = $movement_stmt->fetchAll();
    ?>
    <?php if (!$movements): ?><tr><td colspan="7" class="text-center text-muted">No stock movements recorded yet.</td></tr>
    <?php else: foreach ($movements as $m): ?><tr>
        <td><?php echo date('M d, Y h:i A', strtotime($m['created_at'])); ?></td>
        <td><strong><?php echo htmlspecialchars($m['product_name']); ?></strong></td>
        <td><?php echo htmlspecialchars(ucwords(str_replace('_',' ',$m['movement_type']))); ?></td>
        <td><?php echo ((int)$m['quantity_change'] > 0 ? '+' : '') . (int)$m['quantity_change']; ?></td>
        <td><?php echo htmlspecialchars($m['location']); ?></td>
        <td><?php echo htmlspecialchars($m['reference_no'] ?? '-'); ?></td>
        <td><?php echo htmlspecialchars($m['user_name']); ?></td>
    </tr><?php endforeach; endif; ?>
    </tbody></table></div></div>
</div>

<!-- Restock Modal -->
<div id="restockModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-truck"></i> Restock Product</h3>
            <button class="close-modal" onclick="closeModal('restockModal')">&times;</button>
        </div>
        <div class="modal-body">
            <form method="POST" id="restockForm">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrf_token()); ?>">
                <input type="hidden" name="product_id" id="restock_product_id">
                <input type="hidden" name="stock_action" value="restock">
                <div class="form-group">
                    <label>Product</label>
                    <p id="restock_product_name" class="form-text"></p>
                </div>
                <div class="form-group">
                    <label>Current Stock</label>
                    <p id="restock_current_stock" class="form-text"></p>
                </div>
                <div class="form-group">
                    <label for="add_quantity">Quantity to Add</label>
                    <input type="number" id="add_quantity" name="add_quantity" min="1" required>
                </div>
                <button type="submit" class="btn btn-primary btn-block">
                    <i class="fas fa-plus"></i> Add to Stock
                </button>
            </form>
        </div>
    </div>
</div>

<!-- Update Stock Modal -->
<div id="updateModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-edit"></i> Update Stock</h3>
            <button class="close-modal" onclick="closeModal('updateModal')">&times;</button>
        </div>
        <div class="modal-body">
            <form method="POST" id="updateForm">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrf_token()); ?>">
                <input type="hidden" name="product_id" id="update_product_id">
                <input type="hidden" name="stock_action" value="update">
                <div class="form-group">
                    <label>Product</label>
                    <p id="update_product_name" class="form-text"></p>
                </div>
                <div class="form-group">
                    <label for="new_stock">New Stock Quantity</label>
                    <input type="number" id="new_stock" name="new_stock" min="0" required>
                </div>
                <button type="submit" class="btn btn-primary btn-block">
                    <i class="fas fa-save"></i> Update Stock
                </button>
            </form>
        </div>
    </div>
</div>

<script>
function openRestockModal(id, name, stock) {
    document.getElementById('restock_product_id').value = id;
    document.getElementById('restock_product_name').textContent = name;
    document.getElementById('restock_current_stock').textContent = stock + ' units';
    document.getElementById('add_quantity').value = '';
    document.getElementById('restockModal').classList.add('active');
}

function openUpdateModal(id, name, stock) {
    document.getElementById('update_product_id').value = id;
    document.getElementById('update_product_name').textContent = name;
    document.getElementById('new_stock').value = stock;
    document.getElementById('updateModal').classList.add('active');
}

function closeModal(id) {
    document.getElementById(id).classList.remove('active');
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
