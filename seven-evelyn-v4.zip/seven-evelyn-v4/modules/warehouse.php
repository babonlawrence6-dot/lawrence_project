<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/pagination.php';

require_role($pdo, ['admin', 'owner', 'warehouse']);

$pageTitle = 'Warehouse Management';
$message = '';
$message_type = '';

$locations = [];
try {
    $locations = $pdo->query("SELECT id, name FROM locations WHERE active = 1 ORDER BY name")->fetchAll();
} catch (PDOException $e) {
    $locations = [];
}

// Receive supplier delivery into Main Store.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['receive_delivery'])) {
    verify_csrf();
    $ref_no = trim($_POST['ref_no'] ?? '');
    $supplier = trim($_POST['supplier'] ?? '');
    $product_id = (int)($_POST['product_id'] ?? 0);
    $quantity = (int)($_POST['quantity'] ?? 0);

    if ($ref_no === '' || $product_id <= 0 || $quantity <= 0) {
        $message = 'Please fill all required fields correctly.';
        $message_type = 'error';
    } else {
        try {
            $pdo->beginTransaction();
            $check = $pdo->prepare('SELECT id, cost_price FROM products WHERE id = ? FOR UPDATE');
            $check->execute([$product_id]);
            $product = $check->fetch();
            if (!$product) throw new RuntimeException('Selected product does not exist.');

            $stmt = $pdo->prepare("INSERT INTO deliveries (reference_no, supplier_name, received_by, total_items, status, received_at) VALUES (?, ?, ?, ?, 'received', NOW())");
            $stmt->execute([$ref_no, $supplier, get_current_user_id(), $quantity]);
            $delivery_id = $pdo->lastInsertId();

            $stmt = $pdo->prepare("INSERT INTO delivery_items (delivery_id, product_id, quantity, cost_price) VALUES (?, ?, ?, ?)");
            $stmt->execute([$delivery_id, $product_id, $quantity, $product['cost_price']]);

            $stmt = $pdo->prepare("UPDATE products SET stock = stock + ? WHERE id = ?");
            $stmt->execute([$quantity, $product_id]);
            record_stock_movement($pdo, $product_id, $quantity, 'delivery', $ref_no, get_current_user_id(), 'Main Store', 'Supplier delivery received');

            $pdo->commit();
            $message = 'Delivery received successfully. Main Store stock was updated.';
            $message_type = 'success';
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $message = $e instanceof RuntimeException ? $e->getMessage() : 'Error receiving delivery. Reference number may already exist.';
            $message_type = 'error';
        }
    }
}

// Stock transfer between configured locations.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_transfer'])) {
    verify_csrf();
    $from = trim($_POST['from_location'] ?? '');
    $to = trim($_POST['to_location'] ?? '');
    $product_id = (int)($_POST['transfer_product_id'] ?? 0);
    $quantity = (int)($_POST['transfer_quantity'] ?? 0);

    if ($from === '' || $to === '' || $from === $to || $product_id <= 0 || $quantity <= 0) {
        $message = 'Choose different source and destination locations and enter a valid quantity.';
        $message_type = 'error';
    } else {
        try {
            $validLocations = array_column($locations, 'name');
            if (!in_array($from, $validLocations, true) || !in_array($to, $validLocations, true)) {
                throw new RuntimeException('Invalid transfer location.');
            }

            $pdo->beginTransaction();

            // Lock both ends in deterministic location order to reduce deadlock risk.
            $ordered = [$from, $to];
            sort($ordered, SORT_STRING);
            foreach ($ordered as $loc) {
                if ($loc === 'Main Store') {
                    $stmt = $pdo->prepare('SELECT id, stock FROM products WHERE id = ? FOR UPDATE');
                    $stmt->execute([$product_id]);
                    if (!$stmt->fetch()) throw new RuntimeException('Product not found.');
                } else {
                    $stmt = $pdo->prepare('SELECT id, stock FROM location_stock WHERE location_id = (SELECT id FROM locations WHERE name = ?) AND product_id = ? FOR UPDATE');
                    $stmt->execute([$loc, $product_id]);
                    // A missing row is treated as zero and will be created when needed.
                }
            }

            $getMain = $pdo->prepare('SELECT stock FROM products WHERE id = ? FOR UPDATE');
            $getMain->execute([$product_id]);
            $mainStock = (int)$getMain->fetchColumn();

            $getOther = $pdo->prepare("SELECT l.name, COALESCE(ls.stock,0) AS stock FROM locations l LEFT JOIN location_stock ls ON ls.location_id=l.id AND ls.product_id=? WHERE l.name IN (?,?) FOR UPDATE");
            $getOther->execute([$product_id, $from, $to]);
            $balances = [];
            foreach ($getOther->fetchAll() as $row) $balances[$row['name']] = (int)$row['stock'];
            $balances['Main Store'] = $mainStock;

            $available = $balances[$from] ?? 0;
            if ($available < $quantity) {
                throw new RuntimeException("Not enough stock at {$from}. Available: {$available}.");
            }

            $transfer_no = 'TRF-' . date('YmdHis') . '-' . strtoupper(bin2hex(random_bytes(3)));
            $stmt = $pdo->prepare("INSERT INTO stock_transfers (transfer_no, from_location, to_location, processed_by, status) VALUES (?, ?, ?, ?, 'completed')");
            $stmt->execute([$transfer_no, $from, $to, get_current_user_id()]);
            $transfer_id = $pdo->lastInsertId();

            $stmt = $pdo->prepare('INSERT INTO stock_transfer_items (transfer_id, product_id, quantity) VALUES (?, ?, ?)');
            $stmt->execute([$transfer_id, $product_id, $quantity]);

            // Deduct source.
            if ($from === 'Main Store') {
                $stmt = $pdo->prepare('UPDATE products SET stock = stock - ? WHERE id = ? AND stock >= ?');
                $stmt->execute([$quantity, $product_id, $quantity]);
                if ($stmt->rowCount() !== 1) throw new RuntimeException('Source stock changed. Please retry.');
            } else {
                $stmt = $pdo->prepare('UPDATE location_stock SET stock = stock - ? WHERE location_id=(SELECT id FROM locations WHERE name=?) AND product_id=? AND stock>=?');
                $stmt->execute([$quantity, $from, $product_id, $quantity]);
                if ($stmt->rowCount() !== 1) throw new RuntimeException('Source stock changed. Please retry.');
            }

            // Add destination.
            if ($to === 'Main Store') {
                $stmt = $pdo->prepare('UPDATE products SET stock = stock + ? WHERE id = ?');
                $stmt->execute([$quantity, $product_id]);
            } else {
                $stmt = $pdo->prepare('INSERT INTO location_stock (location_id, product_id, stock) SELECT id, ?, ? FROM locations WHERE name=? ON DUPLICATE KEY UPDATE stock=stock+VALUES(stock)');
                $stmt->execute([$product_id, $quantity, $to]);
            }

            record_stock_movement($pdo, $product_id, -$quantity, 'transfer_out', $transfer_no, get_current_user_id(), $from, 'Transfer to ' . $to);
            record_stock_movement($pdo, $product_id, $quantity, 'transfer_in', $transfer_no, get_current_user_id(), $to, 'Transfer from ' . $from);

            $pdo->commit();
            $message = "Transfer {$transfer_no} completed successfully.";
            $message_type = 'success';
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $message = $e instanceof RuntimeException ? $e->getMessage() : 'Error creating stock transfer.';
            $message_type = 'error';
        }
    }
}

$products = $pdo->query("SELECT id, name, barcode FROM products ORDER BY name ASC")->fetchAll();

// Location summary.
$location_summary = [];
foreach ($locations as $loc) {
    if ($loc['name'] === 'Main Store') {
        $stmt = $pdo->query('SELECT COALESCE(SUM(stock),0) FROM products');
        $units = (int)$stmt->fetchColumn();
    } else {
        $stmt = $pdo->prepare('SELECT COALESCE(SUM(stock),0) FROM location_stock WHERE location_id=?');
        $stmt->execute([$loc['id']]);
        $units = (int)$stmt->fetchColumn();
    }
    $location_summary[$loc['name']] = $units;
}

$per_page = get_per_page();
$page = get_current_page();
$search = get_search_query();
$sort_columns = ['reference_no'=>'d.reference_no','supplier_name'=>'d.supplier_name','total_items'=>'d.total_items','receiver'=>'u.full_name','created_at'=>'d.created_at','status'=>'d.status'];
$sort = get_sort_column($sort_columns, 'created_at');
$dir = get_sort_direction('DESC');
$where_sql = '';
$params = [];
if ($search !== '') {
    $where_sql = 'WHERE (d.reference_no LIKE :q1 OR d.supplier_name LIKE :q2 OR u.full_name LIKE :q3)';
    $like = '%' . $search . '%';
    $params = [':q1'=>$like, ':q2'=>$like, ':q3'=>$like];
}
$count_stmt = $pdo->prepare("SELECT COUNT(*) FROM deliveries d JOIN users u ON d.received_by=u.id $where_sql");
$count_stmt->execute($params);
$total_deliveries = (int)$count_stmt->fetchColumn();
$stmt = $pdo->prepare("SELECT d.*,u.full_name receiver FROM deliveries d JOIN users u ON d.received_by=u.id $where_sql ORDER BY {$sort_columns[$sort]} $dir LIMIT :limit OFFSET :offset");
foreach ($params as $k=>$v) $stmt->bindValue($k,$v);
$stmt->bindValue(':limit',$per_page,PDO::PARAM_INT);
$stmt->bindValue(':offset',get_pagination_offset($page,$per_page),PDO::PARAM_INT);
$stmt->execute();
$recent_deliveries = $stmt->fetchAll();

$transfer_stmt = $pdo->query("SELECT st.*,u.full_name, COUNT(sti.id) item_lines, COALESCE(SUM(sti.quantity),0) total_units FROM stock_transfers st JOIN users u ON st.processed_by=u.id LEFT JOIN stock_transfer_items sti ON sti.transfer_id=st.id GROUP BY st.id ORDER BY st.created_at DESC LIMIT 20");
$recent_transfers = $transfer_stmt->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<?php if ($message): ?>
<div class="alert alert-<?php echo $message_type; ?> alert-dismissible">
    <i class="fas fa-<?php echo $message_type === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
    <?php echo htmlspecialchars($message); ?>
    <button class="close-btn" onclick="this.parentElement.remove()">&times;</button>
</div>
<?php endif; ?>

<div class="dashboard-grid mb-3">
<?php foreach ($location_summary as $name=>$units): ?>
    <div class="stat-card">
        <div class="stat-icon bg-purple"><i class="fas fa-warehouse"></i></div>
        <div class="stat-info"><h3><?php echo number_format($units); ?></h3><p><?php echo htmlspecialchars($name); ?> Units</p></div>
    </div>
<?php endforeach; ?>
</div>

<div class="dashboard-grid mb-3">
    <div class="card">
        <div class="card-header"><h3><i class="fas fa-truck"></i> Receive Delivery</h3></div>
        <div class="card-body">
            <p class="text-muted">Add supplier stock directly to Main Store.</p>
            <button class="btn btn-primary" onclick="document.getElementById('deliveryModal').classList.add('active')"><i class="fas fa-plus"></i> New Delivery</button>
        </div>
    </div>
    <div class="card">
        <div class="card-header"><h3><i class="fas fa-exchange-alt"></i> Stock Transfer</h3></div>
        <div class="card-body">
            <p class="text-muted">Move available stock between locations.</p>
            <button class="btn btn-secondary" onclick="document.getElementById('transferModal').classList.add('active')"><i class="fas fa-arrow-right"></i> New Transfer</button>
        </div>
    </div>
</div>

<div class="card mb-3">
    <div class="card-header"><h3><i class="fas fa-history"></i> Recent Transfers</h3></div>
    <div class="card-body">
        <div class="table-responsive"><table class="table table-striped"><thead><tr><th>Transfer No.</th><th>From</th><th>To</th><th>Units</th><th>Processed By</th><th>Date</th><th>Status</th></tr></thead><tbody>
        <?php if (!$recent_transfers): ?><tr><td colspan="7" class="text-center text-muted">No transfers yet.</td></tr>
        <?php else: foreach ($recent_transfers as $t): ?><tr>
            <td><strong><?php echo htmlspecialchars($t['transfer_no']); ?></strong></td>
            <td><?php echo htmlspecialchars($t['from_location']); ?></td><td><?php echo htmlspecialchars($t['to_location']); ?></td>
            <td><?php echo (int)$t['total_units']; ?></td><td><?php echo htmlspecialchars($t['full_name']); ?></td>
            <td><?php echo date('M d, Y h:i A', strtotime($t['created_at'])); ?></td>
            <td><span class="badge badge-success"><?php echo ucfirst($t['status']); ?></span></td>
        </tr><?php endforeach; endif; ?></tbody></table></div>
    </div>
</div>

<div class="card">
    <div class="card-header"><h3><i class="fas fa-history"></i> Delivery History</h3><div class="header-actions"><?php render_search_box($search,'Search deliveries...'); ?><?php render_per_page_selector($per_page); ?></div></div>
    <div class="card-body"><div class="table-responsive"><table class="table table-striped"><thead><tr>
        <th><?php render_sort_link('Ref No.','reference_no',$sort,$dir); ?></th><th><?php render_sort_link('Supplier','supplier_name',$sort,$dir); ?></th><th><?php render_sort_link('Items','total_items',$sort,$dir); ?></th><th><?php render_sort_link('Received By','receiver',$sort,$dir); ?></th><th><?php render_sort_link('Date','created_at',$sort,$dir); ?></th><th><?php render_sort_link('Status','status',$sort,$dir); ?></th>
    </tr></thead><tbody>
    <?php if (!$recent_deliveries): ?><tr><td colspan="6" class="text-center text-muted">No deliveries found.</td></tr>
    <?php else: foreach ($recent_deliveries as $d): ?><tr><td><strong><?php echo htmlspecialchars($d['reference_no']); ?></strong></td><td><?php echo htmlspecialchars($d['supplier_name']); ?></td><td><?php echo (int)$d['total_items']; ?></td><td><?php echo htmlspecialchars($d['receiver']); ?></td><td><?php echo date('M d, Y h:i A',strtotime($d['created_at'])); ?></td><td><span class="badge badge-success"><?php echo ucfirst($d['status']); ?></span></td></tr><?php endforeach; endif; ?>
    </tbody></table></div><?php render_pagination($page,$total_deliveries,$per_page); ?></div>
</div>

<div id="deliveryModal" class="modal"><div class="modal-content"><div class="modal-header"><h3>Receive New Delivery</h3><button class="close-modal" onclick="closeWarehouseModal('deliveryModal')">&times;</button></div><form method="POST"><input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrf_token()); ?>"><div class="modal-body">
    <div class="form-group"><label>Reference Number</label><input type="text" name="ref_no" required placeholder="e.g. PO-12345" maxlength="50"></div>
    <div class="form-group"><label>Supplier Name</label><input type="text" name="supplier" maxlength="100"></div>
    <div class="form-group"><label>Product</label><select name="product_id" required><option value="">-- Select Product --</option><?php foreach($products as $p): ?><option value="<?php echo (int)$p['id']; ?>"><?php echo htmlspecialchars($p['name']); ?> (<?php echo htmlspecialchars($p['barcode'] ?? '-'); ?>)</option><?php endforeach; ?></select></div>
    <div class="form-group"><label>Quantity Received</label><input type="number" name="quantity" min="1" required></div>
</div><div class="modal-footer"><button type="button" class="btn btn-secondary" onclick="closeWarehouseModal('deliveryModal')">Cancel</button><button type="submit" name="receive_delivery" class="btn btn-primary">Receive Stock</button></div></form></div></div>

<div id="transferModal" class="modal"><div class="modal-content"><div class="modal-header"><h3>Create Stock Transfer</h3><button class="close-modal" onclick="closeWarehouseModal('transferModal')">&times;</button></div><form method="POST"><input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrf_token()); ?>"><div class="modal-body">
    <div class="form-group"><label>From Location</label><select name="from_location" id="fromLocation" required><option value="">-- Select Source --</option><?php foreach($locations as $l): ?><option value="<?php echo htmlspecialchars($l['name'],ENT_QUOTES); ?>"><?php echo htmlspecialchars($l['name']); ?></option><?php endforeach; ?></select></div>
    <div class="form-group"><label>To Location</label><select name="to_location" id="toLocation" required><option value="">-- Select Destination --</option><?php foreach($locations as $l): ?><option value="<?php echo htmlspecialchars($l['name'],ENT_QUOTES); ?>"><?php echo htmlspecialchars($l['name']); ?></option><?php endforeach; ?></select></div>
    <div class="form-group"><label>Product</label><select name="transfer_product_id" required><option value="">-- Select Product --</option><?php foreach($products as $p): ?><option value="<?php echo (int)$p['id']; ?>"><?php echo htmlspecialchars($p['name']); ?></option><?php endforeach; ?></select></div>
    <div class="form-group"><label>Quantity</label><input type="number" name="transfer_quantity" min="1" required></div>
    <div class="alert alert-info"><i class="fas fa-info-circle"></i> Transfers are completed immediately and recorded in transfer history.</div>
</div><div class="modal-footer"><button type="button" class="btn btn-secondary" onclick="closeWarehouseModal('transferModal')">Cancel</button><button type="submit" name="create_transfer" class="btn btn-primary">Complete Transfer</button></div></form></div></div>

<style>.modal{display:none;position:fixed;z-index:1000;left:0;top:0;width:100%;height:100%;background:rgba(0,0,0,.5)}.modal.active{display:block}.modal-content{background:#fff;margin:7% auto;padding:0;border-radius:8px;width:min(520px,92%);box-shadow:0 4px 8px rgba(0,0,0,.2)}.modal-header{padding:15px 20px;border-bottom:1px solid #eee;display:flex;justify-content:space-between;align-items:center}.modal-body{padding:20px}.modal-footer{padding:15px 20px;border-top:1px solid #eee;text-align:right}.close-modal{border:0;background:none;font-size:28px;cursor:pointer}.form-group{margin-bottom:15px}.form-group label{display:block;margin-bottom:5px;font-weight:bold}.form-group input,.form-group select{width:100%;padding:8px;border:1px solid #ddd;border-radius:4px}</style>
<script>function closeWarehouseModal(id){document.getElementById(id).classList.remove('active')}document.getElementById('fromLocation')?.addEventListener('change',function(){const to=document.getElementById('toLocation');Array.from(to.options).forEach(o=>o.disabled=o.value!==''&&o.value===this.value);if(to.value===this.value)to.value='';});</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
